﻿#include <GL/glut.h>
#include <GL/glu.h>
#include <math.h>
#include<Windows.h>
#include<texture.h>
#include<iostream>

float cameraPosX = 0;
float cameraPosY = 5;
float cameraPosZ = 0;
float speed = 20.0f;
float targetPosX = 0;
float targetPosY = 0;
float targetPosZ = 0;

int auto_door1 = 117;
int auto_door2 = 125;


double horizontalAngle = 0;
double verticalAngle = 0;
int r = 1;

int skyboxsize = 2300;

int field_length = 300;// *2
int field_width = 200;// *2

float tx = 0;
float tz = 0;
float ty = 0;

int frot = 0;

float goalAreaLength = 55; //goal area length
float goalAreaWidth = 50; // goal area width

float penaltyAreaLength = 90; // Standard penalty area length
float penaltyAreaWidth = 75; // Standard penalty area width

float cornerRadius = 8.0f; // Standard corner radius

float roofmove = 0;
float rooftop = 0;

bool doorstate = false;
float doorangle = 0;

GLUquadricObj* obj = gluNewQuadric();

#define SCREEN_WIDTH	800
#define SCREEN_HEIGHT	600
#define CAMERA_SPEED  (3.14/180*0.2)


void passiveMotion(int x, int y) {
	// This variable is hack to stop glutWarpPointer from triggering an event callback to Mouse(...)
	// This avoids it being called recursively and hanging up the event loop
	static bool just_warped = false;

	if (just_warped) {
		just_warped = false;
		return;
	}
	int dx = x - SCREEN_WIDTH / 2;
	int dy = y - SCREEN_HEIGHT / 2;

	if (dx) {
		horizontalAngle = horizontalAngle - CAMERA_SPEED * dx;
	}

	if (dy) {
		verticalAngle = verticalAngle + CAMERA_SPEED * dy;
	}

	glutWarpPointer(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2);

	just_warped = true;
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case VK_ESCAPE: /* Escape key */
		exit(0);
		break;
	case 'a':
		cameraPosX = cameraPosX - speed * cos(horizontalAngle); // Move right
		cameraPosZ = cameraPosZ + speed * sin(horizontalAngle);
		break;
	case 'w':
		cameraPosX = cameraPosX - speed * sin(horizontalAngle); // Move forward
		cameraPosZ = cameraPosZ - speed * cos(horizontalAngle);
		break;
	case 'd':

		cameraPosX = cameraPosX + speed * cos(horizontalAngle); // Move left
		cameraPosZ = cameraPosZ - speed * sin(horizontalAngle);
		break;
	case 's':
		cameraPosX = cameraPosX + speed * sin(horizontalAngle); // Move backward
		cameraPosZ = cameraPosZ + speed * cos(horizontalAngle);
		break;
	case 32:
		cameraPosY += 10.0f;
		break;
	case 'q': // Move up
		cameraPosY += speed;
		break;
	case 'e': // Move down
		cameraPosY -= speed;
		break;
	case'r':
		if (doorstate == false) {
			doorangle = 90;
			doorstate = true;
		}
		else {
			doorangle = 0;
			doorstate = false;
		}
	case 'f': //open roof
		if (roofmove < -100)
			break;
		roofmove -= 3;
		rooftop -= 0.1;
		break;
	case 't': //close roof
		if (roofmove > -0.25)
			break;
		roofmove += 3;
		rooftop += 0.1;
		break;

	default:
		break;
	}
	glutPostRedisplay();
}
void special(int key, int x, int y) {
	switch (key) {
	case GLUT_KEY_RIGHT:
		tx += 10;
		std::cout << tx << "   " << tz << " " << ty << "\n";
		break;
	case GLUT_KEY_LEFT:
		tx -= 10;
		std::cout << tx << "   " << tz << " " << ty << "\n";
		break;
	case GLUT_KEY_UP:
		tz += 5;
		std::cout << tx << "   " << tz << " " << ty << "\n";
	case GLUT_KEY_DOWN:
		tz -= 5;
		std::cout << tx << "   " << tz << " " << ty << "\n";
		break;
	case GLUT_KEY_F1:
		ty -= 5;
		std::cout << tx << "   " << tz <<" "  << ty<< "\n";
		break;
	case GLUT_KEY_F2:
		ty += 5;
		std::cout << tx << "   " << tz << " " << ty << "\n";
		break;
	default:
		break;
	}
}

float gravity = -0.05f; // Gravity constant
void update() {
	if (cameraPosY > 5.0f) {
		cameraPosY += gravity; // Apply gravity
	}
	else {
		cameraPosY = 5.0f; // Ground level
	}
}


void createFlag() {

	glNewList(21, GL_COMPILE);
	//corner flag pole
	glPushMatrix();
	//glTranslatef(tx, 11, tz);
	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glColor3f(0.2, 0.2, 0.2);
	gluCylinder(obj, 0.125, 0.125, 14, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glTranslatef(0, 0, 13);
	glColor3f(0, 0, 0);
	gluCylinder(obj, 0.126, 0.126, 1, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glColor3f(1, 1, 0);
	gluCylinder(obj, 0.126, 0.126, 1.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glTranslatef(0, 0, 1.5);
	glColor3f(1, 0, 0);
	gluCylinder(obj, 0.126, 0.126, 1.5, 32, 32);
	glPopMatrix();

	//flag
	glPushMatrix();
	glColor3f(1, 1, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, -0.1);
	glVertex3d(0, -1.5, -0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, 0, -0.1);

	glVertex3d(1.5, 0, -0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(1.5, 0, 0.1);

	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(0, -1.5, -0.1);
	glVertex3d(0, -1.5, 0.1);
	glVertex3d(1.5, -1.5, 0.1);

	glVertex3d(0, 0, -0.1);
	glVertex3d(0, -1.5, -0.1);
	glVertex3d(0, -1.5, 0.1);
	glVertex3d(0, 0, 0.1);

	glVertex3d(1.5, 0, 0.1);
	glVertex3d(0, 0, 0.1);
	glVertex3d(0, -1.5, 0.1);
	glVertex3d(1.5, -1.5, 0.1);

	glVertex3d(0, 0, -0.1);
	glVertex3d(0, 0, 0.1);
	glVertex3d(1.5, 0, 0.1);
	glVertex3d(1.5, 0, -0.1);
	glEnd();
	//glPopMatrix();


	//glPushMatrix();
	glColor3f(1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, -1.5, -0.1);
	glVertex3d(0, -3, -0.1);
	glVertex3d(1.5, -3, -0.1);
	glVertex3d(1.5, -1.5, -0.1);

	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -3, -0.1);
	glVertex3d(1.5, -3, 0.1);
	glVertex3d(1.5, -1.5, 0.1);

	glVertex3d(1.5, -3, -0.1);
	glVertex3d(0, -3, -0.1);
	glVertex3d(0, -3, 0.1);
	glVertex3d(1.5, -3, 0.1);

	glVertex3d(0, -1.5, -0.1);
	glVertex3d(0, -3, -0.1);
	glVertex3d(0, -3, 0.1);
	glVertex3d(0, -1.5, 0.1);

	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(0, -1.5, 0.1);
	glVertex3d(0, -3, 0.1);
	glVertex3d(1.5, -3, 0.1);

	glVertex3d(0, -1.5, -0.1);
	glVertex3d(0, -1.5, 0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glEnd();
	//glPopMatrix();


	//glPushMatrix();
	glColor3f(1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(1.5, 0, -0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(3, -1.5, -0.1);
	glVertex3d(3, 0, -0.1);

	glVertex3d(3, 0, -0.1);
	glVertex3d(3, -1.5, -0.1);
	glVertex3d(3, -1.5, 0.1);
	glVertex3d(3, 0, 0.1);

	glVertex3d(3, -1.5, -0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(3, -1.5, 0.1);

	glVertex3d(1.5, 0, -0.1);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(1.5, 0, 0.1);

	glVertex3d(3, 0, 0.1);
	glVertex3d(1.5, 0, 0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(3, -1.5, 0.1);

	glVertex3d(1.5, 0, -0.1);
	glVertex3d(1.5, 0, 0.1);
	glVertex3d(3, 0, 0.1);
	glVertex3d(3, 0, -0.1);
	glEnd();
	//glPopMatrix();


	//glPushMatrix();
	glColor3f(1, 1, 0);
	glBegin(GL_QUADS);
	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -3, -0.1);
	glVertex3d(3, -3, -0.1);
	glVertex3d(3, -1.5, -0.1);

	glVertex3d(3, -1.5, -0.1);
	glVertex3d(3, -3, -0.1);
	glVertex3d(3, -3, 0.1);
	glVertex3d(3, -1.5, 0.1);

	glVertex3d(3, -3, -0.1);
	glVertex3d(1.5, -3, -0.1);
	glVertex3d(1.5, -3, 0.1);
	glVertex3d(3, -3, 0.1);

	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -3, -0.1);
	glVertex3d(1.5, -3, 0.1);
	glVertex3d(1.5, -1.5, 0.1);

	glVertex3d(3, -1.5, 0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(1.5, -3, 0.1);
	glVertex3d(3, -3, 0.1);

	glVertex3d(1.5, -1.5, -0.1);
	glVertex3d(1.5, -1.5, 0.1);
	glVertex3d(3, -1.5, 0.1);
	glVertex3d(3, -1.5, -0.1);
	glEnd();
	glPopMatrix();
	glPopMatrix();
	glPopMatrix();

	glEndList();
}
void createNet() {
	//net//
	glNewList(1, GL_COMPILE);
	//vertical back lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -30);
	glTranslatef(-3.5, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 24.4, 100, 100);
	glPopMatrix();
	glEndList();

	glNewList(2, GL_COMPILE);
	//horizontal back lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -30);
	glRotatef(180, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.25, 0.25, 74, 100, 100);
	glPopMatrix();

	//horizontal right lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glTranslatef(73.2, 0, 0);
	glRotatef(180, 1, 0, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.25, 0.25, 15, 100, 100);
	glPopMatrix();

	//horizontal left lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(180, 1, 0, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.25, 0.25, 15, 100, 100);
	glPopMatrix();

	//vertical top lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glTranslatef(73.2, 0, 0);
	glRotatef(180, 1, 0, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.25, 0.25, 15, 100, 100);
	glPopMatrix();
	glEndList();

	glNewList(3, GL_COMPILE);
	//LEFT VERTICAL LINES//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 24.4, 100, 100);
	glPopMatrix();

	//right vertical lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glTranslatef(73.2, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 24.4, 100, 100);
	glPopMatrix();

	//horizontal top lines//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(180, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.25, 0.25, 73.2, 100, 100);
	glPopMatrix();
	glEndList();


}
void createBunch() {
	//glass division
	glNewList(11, GL_COMPILE);
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glRotatef(-90, 0, 1, 0);
	glTranslatef(-0.1, 0, 0);
	gluPartialDisk(obj, 9.7, 10.1, 32, 32, 180, 180);
	glPopMatrix();
	glEndList();

	//chairs
	glNewList(12, GL_COMPILE);
	//chair base
	glPushMatrix();
	glColor3f(0, 0, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0, 0);

	glVertex3d(5, 0, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0.5, 5);
	glVertex3d(5, 0, 5);

	glVertex3d(5, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(5, 0.5, 5);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 5);
	glVertex3d(5, 0, 5);
	glVertex3d(5, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(0, 0, 5);

	glVertex3d(0, 0, 5);
	glVertex3d(0, 0.5, 5);
	glVertex3d(5, 0.5, 5);
	glVertex3d(5, 0, 5);

	glEnd();
	glPopMatrix();


	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0.5, 0);
	glBegin(GL_QUADS);
	glVertex3d(1, 0, 0);
	glVertex3d(1, 0.05, 0);
	glVertex3d(4, 0.05, 0);
	glVertex3d(4, 0, 0);

	glVertex3d(4, 0, 0);
	glVertex3d(4, 0.05, 0);
	glVertex3d(4, 0.05, 5);
	glVertex3d(4, 0, 5);

	glVertex3d(4, 0.05, 0);
	glVertex3d(1, 0.05, 0);
	glVertex3d(1, 0.05, 5);
	glVertex3d(4, 0.05, 5);

	glVertex3d(1, 0, 0);
	glVertex3d(1, 0, 5);
	glVertex3d(4, 0, 5);
	glVertex3d(4, 0, 0);

	glVertex3d(1, 0, 0);
	glVertex3d(1, 0.1, 0);
	glVertex3d(1, 0.05, 5);
	glVertex3d(1, 0, 5);

	glVertex3d(1, 0, 5);
	glVertex3d(1, 0.05, 5);
	glVertex3d(4, 0.05, 5);
	glVertex3d(4, 0, 5);

	glEnd();
	glPopMatrix();



	//chair back
	glPushMatrix();
	glColor3f(0, 0, 1);
	glRotatef(-90, 1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0, 0);

	glVertex3d(5, 0, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0.5, 6);
	glVertex3d(5, 0, 6);

	glVertex3d(5, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 6);
	glVertex3d(5, 0.5, 6);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 6);
	glVertex3d(5, 0, 6);
	glVertex3d(5, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 6);
	glVertex3d(0, 0, 6);

	glVertex3d(0, 0, 6);
	glVertex3d(0, 0.5, 6);
	glVertex3d(5, 0.5, 6);
	glVertex3d(5, 0, 6);

	glEnd();
	glPopMatrix();


	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, 0.05);
	glRotatef(-90, 1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(1, 0, 0);
	glVertex3d(1, 0.05, 0);
	glVertex3d(4, 0.05, 0);
	glVertex3d(4, 0, 0);

	glVertex3d(4, 0, 0);
	glVertex3d(4, 0.05, 0);
	glVertex3d(4, 0.05, 5);
	glVertex3d(4, 0, 5);

	glVertex3d(4, 0.05, 0);
	glVertex3d(1, 0.05, 0);
	glVertex3d(1, 0.05, 5);
	glVertex3d(4, 0.05, 5);

	glVertex3d(1, 0, 0);
	glVertex3d(1, 0, 5);
	glVertex3d(4, 0, 5);
	glVertex3d(4, 0, 0);

	glVertex3d(1, 0, 0);
	glVertex3d(1, 0.05, 0);
	glVertex3d(1, 0.05, 5);
	glVertex3d(1, 0, 5);

	glVertex3d(1, 0, 5);
	glVertex3d(1, 0.05, 5);
	glVertex3d(4, 0.05, 5);
	glVertex3d(4, 0, 5);

	glEnd();
	glPopMatrix();


	//head rest
	glPushMatrix();
	glColor3f(0.2, 0.2, 0.2);
	glTranslatef(1.75, 6.5, -0.25);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.1, 0.1, 0.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.2, 0.2, 0.2);
	glTranslatef(3.25, 6.5, -0.25);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.1, 0.1, 0.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0, 0, 1);
	glTranslatef(1.25, 7, -0.25);
	glRotatef(90, 0, 1, 0);
	gluCylinder(obj, 0.5, 0.5, 2.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0, 0, 1);
	glTranslatef(1.25, 7, -0.25);
	glRotatef(90, 0, 1, 0);
	gluDisk(obj, 0, 0.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0, 0, 1);
	glTranslatef(3.75, 7, -0.25);
	glRotatef(90, 0, 1, 0);
	gluDisk(obj, 0, 0.5, 32, 32);
	glPopMatrix();


	//base
	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(2.5, -0.5, 2);
	glutSolidCube(1);
	glTranslatef(0, -1, 0);
	glutSolidCube(1);
	glTranslatef(0, -1, 0);
	glutSolidCube(1);
	glPopMatrix();


	//left armrest
	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(1.85, -0.5, 2);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(-0.3, 0, 0);
	glutSolidCube(0.3);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(-0.25, -0.2, 2);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(-0.6, 1.7, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0.7, 0, 0);

	glVertex3d(0.7, 0, 0);
	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0.7, 0.1, 2);
	glVertex3d(0.7, 0, 2);

	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0.7, 0.1, 2);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2);
	glVertex3d(0.7, 0, 2);
	glVertex3d(0.7, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0, 0, 2);

	glVertex3d(0, 0, 2);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0.7, 0.1, 2);
	glVertex3d(0.7, 0, 2);

	glEnd();
	glPopMatrix();


	//right armrest
	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(3.15, -0.5, 2);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glTranslatef(0.3, 0, 0);
	glutSolidCube(0.3);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(5.25, -0.2, 2);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glTranslatef(0, 0.3, 0);
	glutSolidCube(0.3);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.1, 0.1, 0.1);
	glTranslatef(5, 1.7, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0.7, 0, 0);

	glVertex3d(0.7, 0, 0);
	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0.7, 0.1, 2);
	glVertex3d(0.7, 0, 2);

	glVertex3d(0.7, 0.1, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0.7, 0.1, 2);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2);
	glVertex3d(0.7, 0, 2);
	glVertex3d(0.7, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.1, 0);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0, 0, 2);

	glVertex3d(0, 0, 2);
	glVertex3d(0, 0.1, 2);
	glVertex3d(0.7, 0.1, 2);
	glVertex3d(0.7, 0, 2);

	glEnd();
	glPopMatrix();

	glEndList();


}
void createSubseat() {
	glNewList(4, GL_COMPILE);
	//substitute bench chair base
	glPushMatrix();
	glColor3f(0.3, 0.1, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0, 0);

	glVertex3d(5, 0, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0.5, 5);
	glVertex3d(5, 0, 5);

	glVertex3d(5, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(5, 0.5, 5);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 5);
	glVertex3d(5, 0, 5);
	glVertex3d(5, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(0, 0, 5);

	glVertex3d(0, 0, 5);
	glVertex3d(0, 0.5, 5);
	glVertex3d(5, 0.5, 5);
	glVertex3d(5, 0, 5);

	glEnd();
	glPopMatrix();


	//substitute bench chair back
	glPushMatrix();
	glColor3f(0.3, 0.1, 1);
	glRotatef(-90, 1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0, 0);

	glVertex3d(5, 0, 0);
	glVertex3d(5, 0.5, 0);
	glVertex3d(5, 0.5, 2.5);
	glVertex3d(5, 0, 2.5);

	glVertex3d(5, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(5, 0.5, 2.5);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2.5);
	glVertex3d(5, 0, 2.5);
	glVertex3d(5, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0, 0, 2.5);

	glVertex3d(0, 0, 2.5);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(5, 0.5, 2.5);
	glVertex3d(5, 0, 2.5);

	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.3, 0.1, 1);
	glTranslatef(2.5, 2.5, 0);
	double eq0[4] = { 0, 0, -1,0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, eq0);
	double eq1[4] = { 0, 0, 1,0.5 };
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, eq1);
	glutSolidSphere(2.5, 32, 32);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.3, 0.1, 1);
	glTranslatef(2.5, 2.5, 0);
	gluPartialDisk(obj, 0, 2.5, 32, 32, 270, 180);
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.3, 0.1, 1);
	glTranslatef(2.5, 2.5, -0.5);
	gluPartialDisk(obj, 0, 2.5, 32, 32, 270, 180);
	glPopMatrix();

	glEndList();

	////chair legs//
	glNewList(5, GL_COMPILE);
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, 1);
	glTranslatef(4.5, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 3.5, 100, 100);
	glPopMatrix();
	glEndList();

	//glass division//
	glNewList(6, GL_COMPILE);
	glPushMatrix();
	double eq6[4] = { 1, 0, -1.5,0.0 };
	glEnable(GL_CLIP_PLANE2);
	glClipPlane(GL_CLIP_PLANE2, eq6);
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(4.8, 11, 0);
	glTranslatef(0, 0, 7);
	glRotatef(-90, 0, 1, 0);
	glTranslatef(-0.1, 0, 0);
	//glScalef(1, 1.5, 0);
	gluPartialDisk(obj, 10.7, 11.1, 500, 500, 190, 180.1);
	glDisable(GL_CLIP_PLANE2);
	glPopMatrix();
	glEndList();

}
void create_office() {
	//MKTB DOC 
			//LIST FOR OFFICE//
	glNewList(100, GL_COMPILE);
	//OFFICE TABLE//
	glPushMatrix();
	glColor3f(0.2, 0.2, 0.2);
	glScaled(3, 0.5, 4);
	glutSolidCube(3);

	//LAPTOP//
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, 0.5, 0);
	glColor3f(0, 0, 0);
	glScaled(0.8, 0.3, 0.8);
	glutSolidCube(3);

	//OFFICE TABLE//
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, -2.5, -5);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(3, 2, 1);
	glutSolidCube(3);
	//OFFICE TABLE//
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, -2.5, 5);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(3, 2, 1);
	glutSolidCube(3);

	//OFFICE CHAIR BASE//
	glPopMatrix();
	glPushMatrix();
	glTranslatef(5, -2, 0);
	glColor3f(0.7, 0.7, 0.7);
	glScaled(1, 0.1, 1);
	glutSolidCube(3);

	//OFFICE CHAIR BACK //
	glPopMatrix();
	glPushMatrix();
	glTranslatef(6.4, -0.5, 0);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(0.1, 1, 1);
	glutSolidCube(3);

	//OFFICE CHAIR BACK LEG //
	glPopMatrix();
	glPushMatrix();
	glTranslatef(6.4, -3.5, 1.3);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(0.1, 1, 0.1);
	glutSolidCube(3);

	//OFFICE CHAIR BACK LEG //
	glPopMatrix();
	glPushMatrix();
	glTranslatef(6.4, -3.5, -1.3);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(0.1, 1, 0.1);
	glutSolidCube(3);

	//OFFICE CHAIR FRONT LEG //
	glPopMatrix();
	glPushMatrix();
	glTranslatef(4, -3.5, 1.3);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(0.1, 1, 0.1);
	glutSolidCube(3);

	//OFFICE CHAIR FRONT LEG //
	glPopMatrix();
	glPushMatrix();
	glTranslatef(4, -3.5, -1.3);
	glColor3f(0.2, 0.2, 0.2);
	glScaled(0.1, 1, 0.1);
	glutSolidCube(3);
	glPopMatrix();
	glEndList();
}
void create_abmcar() {
	glNewList(101, GL_COMPILE);
	glPushMatrix();

	glColor3f(1, 1, 1);
	glScalef(15, 15, 25);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -3.97, 15.3);
	glColor3f(0.95, 0.95, 0.95);
	glScalef(14, 7, 8);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, 1, 13);
	glRotated(40, 1, 0, 0);
	glColor3f(0.95, 0.95, 0.95);
	glScalef(14, 9, 9);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -0.4, 17.3);
	glColor3f(0.95, 0.95, 0.95);
	glScalef(14, 4, 4);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, 2, 14);
	glRotated(45, 1, 0, 0);
	glColor3f(0, 0, 0);
	glScalef(12, 6.7, 7);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -2, 15);
	glColor3f(0.5, 0.5, 0.5);
	glScalef(15, 10, 4.5);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glRotated(90, 0, 0, 1);
	glTranslatef(-2, 13, 7.55);
	glScalef(1, 1, 1);
	glColor3f(0, 0, 0);
	gluPartialDisk(obj, 0.25, 0.5, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glRotated(90, 0, 0, 1);
	glTranslatef(-2, 13, -7.55);
	glScalef(1, 1, 1);
	glColor3f(0, 0, 0);
	gluPartialDisk(obj, 0.25, 0.5, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, 1, 15);
	glColor3f(0, 0, 0);
	glScalef(15.2, 3, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-5, -2, 17.9);
	glColor3f(1, 1, 0);
	glScalef(1, 4, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-5, -4.7, 17.9);
	glColor3f(1, 0.6, 0);
	glScalef(1, 1, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(5, -2, 17.9);
	glColor3f(1, 1, 0);
	glScalef(1, 4, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(5, -4.7, 17.9);
	glColor3f(1, 0.6, 0);
	glScalef(1, 1, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -4.7, 17.9);
	glColor3f(0.3, 0.3, 0.3);
	glScalef(5, 3, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-7.5, -7.5, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1, 1, 1.5);
	glutSolidTorus(0.5, 2, 10, 40);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-7.6, -7.5, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0.3, 0.3, 0.3);
	gluDisk(obj, 0, 2, 30, 30);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(-7.6, -7, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1.1, 1, 1);
	gluPartialDisk(obj, 2, 3, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(7.5, -7.5, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1, 1, 1.5);
	glutSolidTorus(0.5, 2, 10, 40);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(7.6, -7.5, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0.3, 0.3, 0.3);
	gluDisk(obj, 0, 2, 30, 30);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(7.6, -7, 8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1.1, 1, 1);
	gluPartialDisk(obj, 2, 3, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-7.5, -7.5, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1, 1, 1.5);
	glutSolidTorus(0.5, 2, 10, 40);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-7.6, -7.5, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0.3, 0.3, 0.3);
	gluDisk(obj, 0, 2, 30, 30);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(-7.6, -7, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1.1, 1, 1);
	gluPartialDisk(obj, 2, 3, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(7.5, -7.5, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1, 1, 1.5);
	glutSolidTorus(0.5, 2, 10, 40);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(7.6, -7.5, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0.3, 0.3, 0.3);
	gluDisk(obj, 0, 2, 30, 30);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(7.6, -7, -8);
	glRotated(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glScalef(1.1, 1, 1);
	gluPartialDisk(obj, 2, 3, 20, 30, -90, 180);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(0, 5.3, 0);
	glColor3f(1, 0, 0);
	glScalef(15.3, 3, 24.9);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(0, -2.3, 0);
	glColor3f(1, 0, 0);
	glScalef(15.3, 3, 24.9);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(0, 1.5, 0);
	glColor3f(1, 0, 0);
	glScalef(15.3, 4, 1.5);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslatef(0, 1.5, 0);
	glColor3f(1, 0, 0);
	glScalef(15.3, 1.5, 4);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, 0, -12.5);
	glRotated(90, 0, 1, 0);
	glColor3f(0.4, 0.4, 0.4);
	glScalef(1, 12, 12);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, 0, -12.7);
	glRotated(90, 0, 1, 0);
	glColor3f(0.7, 0.7, 0.7);
	glScalef(1, 12, 0.5);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(3.3, 3, -12.7);
	glRotated(90, 0, 1, 0);
	glColor3f(0.8, 0.8, 0.8);
	glScalef(1, 3.5, 3.5);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(-3.3, 3, -12.7);
	glRotated(90, 0, 1, 0);
	glColor3f(0.8, 0.8, 0.8);
	glScalef(1, 3.5, 3.5);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -7, 17.9);
	glColor3f(0, 0, 0);
	glScalef(6, 1, 3);
	glutSolidCube(1);
	glPopMatrix();
	//////////////
	glPushMatrix();
	glTranslated(0, -7, -11.5);
	glColor3f(0, 0, 0);
	glScalef(6, 1, 3);
	glutSolidCube(1);
	glPopMatrix();
	/////////////////END IN HERE
	glEndList();
}
void createreception() {
	//ahmad naoura list (30 --> 40)//
			//hospital reseption//
	glNewList(350, GL_COMPILE);
	glPushMatrix();
	//bottom
	glTranslatef(56, 12, -24);
	glTranslatef(7, 0, -1);
	glRotatef(180, 0, 1, 0);
	glPushMatrix();
	glColor3ub(67, 67, 67);
	glScaled(1, 0.1, 1);
	glutSolidCube(4);
	glPopMatrix();
	//back
	glPushMatrix();
	glTranslatef(-1, -1, 0);
	glColor3ub(56, 56, 56);
	glTranslated(3, 3, 0);
	glScaled(0.1, 1, 1);
	glutSolidCube(4);
	glPopMatrix();
	//leg
	glPushMatrix();
	glColor3ub(0, 0, 0);
	glTranslated(-1.4, 0, -1.7);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 0.2, 0.2, 3, 30, 30);
	glPopMatrix();
	//leg
	glPushMatrix();
	glColor3ub(0, 0, 0);
	glTranslated(-1.4, 0, 1.7);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 0.2, 0.2, 3, 30, 30);
	glPopMatrix();
	//leg
	glPushMatrix();
	glColor3ub(0, 0, 0);
	glTranslated(1.7, 0, 1.7);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 0.2, 0.2, 3, 30, 30);
	glPopMatrix();
	//leg
	glPushMatrix();
	glColor3ub(0, 0, 0);
	glTranslated(1.7, 0, -1.7);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 0.2, 0.2, 3, 30, 30);
	glPopMatrix();
	glPopMatrix();
	glEndList();

	glNewList(301, GL_COMPILE);
	glPushMatrix();
	//rs holder
	glPushMatrix();
	glTranslatef(48, -3.5, 42);
	glRotatef(90, 1, 0, 0);
	glColor3ub(184, 122, 87);
	obj = gluNewQuadric();
	gluCylinder(obj, 4, 4, 7, 50, 50);
	glPopMatrix();

	//rs holder
	glPushMatrix();
	glTranslatef(48, -3.5, 100);
	glRotatef(90, 1, 0, 0);
	glColor3ub(184, 122, 87);
	obj = gluNewQuadric();
	gluCylinder(obj, 4, 4, 7, 50, 50);
	glPopMatrix();

	//rs holder
	glPushMatrix();
	glTranslatef(48, -8, 70.5);
	glRotatef(-270, 0, 1, 0);
	glScalef(51, 6, 3);
	glColor3ub(145, 145, 145);
	glutSolidCube(1);
	glPopMatrix();

	//bar
	glPushMatrix();
	glTranslatef(48, -8, 61);
	glScalef(6, 7, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//bar
	glPushMatrix();
	glTranslatef(48, -8, 81);
	glScalef(6, 7, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//bar
	glPushMatrix();
	glTranslatef(60, -8, 40);
	glScalef(25, 7, 3);
	glColor3ub(145, 145, 145);
	glutSolidCube(1);
	glPopMatrix();

	//bar roof
	glPushMatrix();
	glTranslatef(60, 8, 72);
	glRotatef(-270, 0, 1, 0);
	glScalef(65.4, 1.9, 45);
	glColor3ub(145, 145, 145);
	glutSolidCube(1);
	glPopMatrix();

	// بلور bar
	glEnable(GL_BLEND); //for blinging دمج الالوان
	glBlendFunc(GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR); //لدمج الالوان
	glPushMatrix();
	glTranslatef(62, 1.5, 40);
	glScalef(19, 15, 1);
	glColor4ub(93, 140, 218, 0.1);
	glutSolidCube(1);
	glPopMatrix();
	glDisable(GL_BLEND);

	//5zaneh 
	glPushMatrix();
	glTranslatef(68, -8, 102.9);
	glScalef(20, 8, 4);
	glColor3ub(181, 183, 182);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(73, -7, 101);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(62, -7, 101);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();


	//5zaneh 
	glPushMatrix();
	glTranslatef(82.9, -8, 89);
	glRotatef(-270, 0, 1, 0);
	glScalef(12, 8, 4);
	glColor3ub(181, 183, 182);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 86.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 91.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	//5zaneh 
	glPushMatrix();
	glTranslatef(82.9, -8, 70);
	glRotatef(-270, 0, 1, 0);
	glScalef(12, 8, 4);
	glColor3ub(181, 183, 182);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 67.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 72.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();


	//5zaneh 
	glPushMatrix();
	glTranslatef(82.9, -8, 50);
	glRotatef(-270, 0, 1, 0);
	glScalef(12, 8, 4);
	glColor3ub(181, 183, 182);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 47.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(81, -7, 52.5);
	glScalef(0.5, 0.5, 0.5);
	glColor4ub(0, 0, 0, 1);
	glutSolidSphere(1, 60, 60);
	glPopMatrix();

	//cash 1
	glPushMatrix();
	glTranslatef(49, -3.6, 52);
	glRotatef(-270, 0, 1, 0);
	glScalef(4, 3, 1);
	glColor3ub(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//cash 2
	glPushMatrix();
	glTranslatef(49, -3.6, 72);
	glRotatef(-270, 0, 1, 0);
	glScalef(4, 3, 1);
	glColor3ub(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//cash 3
	glPushMatrix();
	glTranslatef(49, -3.6, 89);
	glRotatef(-270, 0, 1, 0);
	glScalef(4, 3, 1);
	glColor3ub(0, 0, 0);
	glutSolidCube(1);
	glPopMatrix();

	//chair 1
	glPushMatrix();
	glTranslatef(117, -19.5, 65);
	glRotatef(180, 0, 1, 0);
	glCallList(350);
	glPopMatrix();

	//chair 2
	glPushMatrix();
	glTranslatef(117, -19.5, 44);
	glRotatef(180, 0, 1, 0);
	glCallList(350);
	glPopMatrix();

	//chair 3
	glPushMatrix();
	glTranslatef(117, -19.5, 27);
	glRotatef(180, 0, 1, 0);
	glCallList(350);
	glPopMatrix();

	//bar up
	glPushMatrix();
	glTranslatef(42, 7, 61);
	glScalef(12, 2, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//bar up
	glPushMatrix();
	glTranslatef(42, 7, 81);
	glScalef(12, 2, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//bar up
	glPushMatrix();
	glTranslatef(42, 7, 44);
	glScalef(12, 2, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//bar up
	glPushMatrix();
	glTranslatef(42, 7, 100);
	glScalef(12, 2, 3);
	glColor3ub(184, 122, 87);
	glutSolidCube(1);
	glPopMatrix();

	//chairs 1
	glPushMatrix();
	glTranslatef(20, -19.5, 158);
	glRotatef(90, 0, 1, 0);
	for (int i = 0; i < 5; i++)
	{
		glTranslated(0, 0, 7);
		glCallList(350);

	}
	glPopMatrix();

	//chairs 2
	glPushMatrix();
	glTranslatef(20, -19.5, -15);
	glRotatef(270, 0, 1, 0);
	for (int i = 0; i < 5; i++)
	{
		glTranslated(0, 0, 7);
		glCallList(350);

	}
	glPopMatrix();

	glPopMatrix();
	glEndList();
}
void createloackrs() {
	glNewList(580, GL_COMPILE);
	//locker//
//locker left//
	glPushMatrix();
	glColor3f(0.7098, 0.3961, 0.1137);
	glRotatef(-90, 1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2.5);
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0, 0, 2.5);

	glVertex3d(0, 0, 2.5);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1

	glEnd();
	glPopMatrix();

	//locker right//
	glPushMatrix();
	glColor3f(0.7098, 0.3961, 0.1137);
	glTranslatef(2, 0, 0);
	glRotatef(-90, 1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(0.1, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2.5);
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0, 0, 2.5);

	glVertex3d(0, 0, 2.5);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0.1, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(0.1, 0, 2.5); // Adjusted from 5 to 0.1

	glEnd();
	glPopMatrix();

	//locker back//
	glPushMatrix();
	glColor3f(0.7098, 0.3961, 0.1137);
	glTranslatef(0, 0, -0.5);
	glRotatef(-90, 1, 0, 0);
	glScalef(1, 2, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(2, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(2, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(2, 0, 0); // Adjusted from 5 to 0.1
	glVertex3d(2, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(2, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(2, 0, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(2, 0.5, 0); // Adjusted from 5 to 0.1
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(2, 0.5, 2.5); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2.5);
	glVertex3d(2, 0, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(2, 0, 0); // Adjusted from 5 to 0.1

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0, 0, 2.5);

	glVertex3d(0, 0, 2.5);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(2, 0.5, 2.5); // Adjusted from 5 to 0.1
	glVertex3d(2, 0, 2.5); // Adjusted from 5 to 0.1

	glEnd();
	glPopMatrix();

	//jersey//
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 1.0f);
	glTranslatef(1, 1.5, -0.25);
	glScalef(2.5, 2.5, 2.5);
	// Draw the body of the T-shirt
	glBegin(GL_QUADS);
	glVertex3f(-0.2f, -0.5f, 0.0f);
	glVertex3f(-0.2f, 0.2f, 0.0f);
	glVertex3f(0.2f, 0.2f, 0.0f);
	glVertex3f(0.2f, -0.5f, 0.0f);
	glEnd();

	// Draw the left sleeve
	glBegin(GL_TRIANGLES);
	glVertex3f(-0.2f, 0.0f, 0.0f);
	glVertex3f(-0.4f, 0.2f, 0.0f);
	glVertex3f(-0.2f, 0.2f, 0.0f);
	glEnd();

	// Draw the right sleeve
	glBegin(GL_TRIANGLES);
	glVertex3f(0.2f, 0.0f, 0.0f);
	glVertex3f(0.4f, 0.2f, 0.0f);
	glVertex3f(0.2f, 0.2f, 0.0f);
	glEnd();
	glPopMatrix();


	// Draw the neck
	glPushMatrix();
	glColor3f(0.7098, 0.3961, 0.1137);
	glTranslatef(1, 2, -0.25);
	glutSolidSphere(0.25, 100, 100);
	glPopMatrix();
	glEndList();

	//glNewList(31, GL_COMPILE); //walls
	//glPushMatrix();
	//glutSolidCube(8);
	//glPopMatrix();
	//glEndList();

	//glNewList(9, GL_COMPILE); //small walls
	//glPushMatrix();
	//glColor3f(0.949, 0.8588, 0.7765);
	//glTranslatef(0, 2, -1.5);
	//glRotatef(90, 1.0f, 0.0f, 0.0f);
	//glRotatef(90, 0.0f, 0.0f, 1.0f);
	//glScalef(1.0f, 0.01f, 1.0f);
	//glutSolidCube(8);
	//glPopMatrix();
	//glEndList();

	////Black Chair.
	//glNewList(500, GL_COMPILE);

	//glPushMatrix();
	////base.
	//glColor3ub(44, 46, 43);
	//glTranslated(0, 0, 0);
	//glRotatef(90, 0, 1, 0);
	//glScaled(3, 0.5, 3);
	//glutSolidCube(1);
	//glPopMatrix();
	//glPushMatrix();
	////F-L leg.
	//glColor3ub(143, 150, 140);
	//glTranslated(-1.25, -1.25, 1.25);
	//glScaled(1, 4, 1);
	//glutSolidCube(0.5);
	//glPopMatrix();
	//glPushMatrix();
	////F-R leg.
	//glTranslated(-1.25, -1.25, -1.25);
	//glScaled(1, 4, 1);
	//glutSolidCube(0.5);
	//glPopMatrix();
	//glPushMatrix();

	////B-R leg.
	//glTranslated(1.25, -1.25, -1.25);
	//glScaled(1, 4, 1);
	//glutSolidCube(0.5);
	//glPopMatrix();
	//glPushMatrix();

	////B-L leg.
	//glTranslated(1.25, -1.25, 1.25);
	//glScaled(1, 4, 1);
	//glutSolidCube(0.5);
	//glPopMatrix();
	//glPushMatrix();

	////Back.

	//glColor3ub(44, 46, 43);
	//glTranslated(1.25, 1.75, 0);
	////glRotated(270, 0, 1, 0);
	//glScaled(0.5, 3, 3);
	//glutSolidCube(1);
	//glPopMatrix();

	//glEndList();



}
void createstages() {
	glNewList(30, GL_COMPILE);
	glPushMatrix();
	glutSolidCube(6);
	glPopMatrix();
	glEndList();
	glNewList(31, GL_COMPILE);
	glPushMatrix();
	glutSolidCube(1);
	glPopMatrix();
	glEndList();
	glNewList(32, GL_COMPILE);
	glPushMatrix();
	glutSolidCube(4);
	glPopMatrix();
	glEndList();
	glNewList(33, GL_COMPILE);//fence
	glPushMatrix();
	glColor3f(0.46, 0.45, 0.53);
	glRotatef(90, 1, 0, 0);
	GLUquadricObj* feence = gluNewQuadric();
	gluCylinder(feence, 0.4, 0.4, 4, 40, 40);
	glPopMatrix();
	glEndList();
	glNewList(34, GL_COMPILE);//fences
	glPushMatrix();
	glColor3f(0.46, 0.45, 0.53);
	glRotatef(90, 1, 0, 0);
	GLUquadricObj* st_fences = gluNewQuadric();
	gluCylinder(st_fences, 0.4, 0.4, 46, 40, 40);
	glPopMatrix();
	glEndList();
	glNewList(35, GL_COMPILE);//SIDES
	glPushMatrix();
	glRotatef(-90, 1, 0, 0);
	glPushMatrix();
	double cut2[4] = { 1, 0, 0.0,0.0 };
	double cut3[4] = { 0, 1, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, cut2);
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, cut3);
	GLUquadricObj* sides = gluNewQuadric();

	gluCylinder(sides, 140, 140, 3, 120, 120);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();
	glPopMatrix();
	glEndList();
	glNewList(36, GL_COMPILE);
	glPushMatrix();
	glutSolidCube(0.2);
	glPopMatrix();
	glEndList();


}

void create() {
	//cooler
	glNewList(50, GL_COMPILE);
	glPushMatrix();
	glColor3ub(172, 189, 230);
	glScaled(3, 7, 3);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();

	glTranslated(1.5, 0.5, 0);
	glColor3ub(51, 47, 69);
	glScaled(0.1, 2, 3);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();

	glTranslated(1.5, 1.75, -.75);
	glColor3ub(0, 2, 186);
	glScaled(0.1, 0.5, 1.5);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();

	glTranslated(1.5, 1.75, .75);
	glColor3ub(191, 0, 3);
	glScaled(0.1, 0.5, 1.5);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();

	glTranslated(0, 4, 0);
	glColor3ub(224, 224, 224);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 1, 1, 0.5, 250, 250);
	glPopMatrix();
	glPushMatrix();

	glTranslated(0, 7, 0);
	glColor3ub(64, 184, 222);
	glRotated(90, 1, 0, 0);
	gluCylinder(obj, 1.25, 1.25, 3, 250, 250);
	glPopMatrix();
	glPushMatrix();

	glTranslated(0, 7, 0);
	glColor3ub(224, 224, 224);
	glScaled(1, 0.2, 1);
	glutSolidSphere(1.25, 250, 250);
	glPopMatrix();
	glEndList();



	//Black Chair.
	glNewList(500, GL_COMPILE);

	glPushMatrix();
	//base.
	glColor3ub(44, 46, 43);
	glTranslated(0, 0, 0);
	glScaled(3, 0.5, 3);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();
	//F-L leg.
	glColor3ub(143, 150, 140);
	glTranslated(-1.25, -1.25, 1.25);
	glScaled(1, 4, 1);
	glutSolidCube(0.5);
	glPopMatrix();
	glPushMatrix();
	//F-R leg.
	glTranslated(-1.25, -1.25, -1.25);
	glScaled(1, 4, 1);
	glutSolidCube(0.5);
	glPopMatrix();
	glPushMatrix();

	//B-R leg.
	glTranslated(1.25, -1.25, -1.25);
	glScaled(1, 4, 1);
	glutSolidCube(0.5);
	glPopMatrix();
	glPushMatrix();

	//B-L leg.
	glTranslated(1.25, -1.25, 1.25);
	glScaled(1, 4, 1);
	glutSolidCube(0.5);
	glPopMatrix();
	glPushMatrix();

	//Back.

	glColor3ub(44, 46, 43);
	glTranslated(1.25, 1.75, 0);
	glScaled(0.5, 3, 3);
	glutSolidCube(1);
	glPopMatrix();

	glEndList();


	//Rounded Chair.
	glNewList(705, GL_COMPILE);
	GLUquadricObj* amr1 = gluNewQuadric();

	glPushMatrix();
	glColor3ub(36, 83, 196);
	glScaled(1, 0.1, 1);
	glutSolidSphere(1, 25, 25);
	glTranslated(0, -0.2, 0);
	glRotated(90, 1, 0, 0);
	glColor3ub(56, 56, 56);
	gluCylinder(amr1, 1, 1, 3, 25, 25);
	glPopMatrix();
	glPushMatrix();
	glTranslated(0, -1, 0);
	glRotated(90, 1, 0, 0);
	gluCylinder(amr1, 1, 1, 0.3, 25, 25);
	glPopMatrix();
	glPushMatrix();
	glColor3ub(121, 122, 116);
	glTranslated(-0.8, 0, 0);
	glRotated(90, 1, 0, 0);
	gluCylinder(amr1, 0.2, 0.2, 3, 25, 25);
	glTranslated(+1.6, 0, 0);
	gluCylinder(amr1, 0.2, 0.2, 3, 25, 25);
	glPopMatrix();
	glEndList();









	//////////////////////////
	//Screen.
	glNewList(900, GL_COMPILE);
	glPushMatrix();
	glTranslated(0, 0, 0);
	glColor3f(0, 0, 0);
	glScaled(0.2, 2, 3);
	glutSolidCube(1);
	//Screen Leg.
	glPopMatrix();
	glPushMatrix();
	glColor3ub(82, 84, 87);
	glTranslated(0, -1.5, 0);
	glScaled(0.1, 1, 0.5);
	glutSolidCube(1);
	//Screen base.
	glPopMatrix();
	glPushMatrix();
	glColor3ub(0, 0, 0);
	glTranslated(0, -2, 0);
	glScaled(0.5, 0.5, 2);
	glutSolidCube(1);
	glPopMatrix();
	glEndList();


	//ROOMS DOOR.
	glNewList(237, GL_COMPILE);
	glPushMatrix();
	glColor3ub(128, 102, 74);
	glScaled(10, 16, 0.125);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glColor3ub(89, 71, 52);
	glTranslated(3, -1, -.375);
	gluSphere(obj, 0.375, 25, 25);
	glPopMatrix();
	glEndList();

	//ROOMS DOOR.
	glNewList(237, GL_COMPILE);
	glPushMatrix();
	glColor3ub(128, 102, 74);
	glScaled(10, 16, 0.125);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glColor3ub(89, 71, 52);
	glTranslated(3, -1, -.375);
	gluSphere(obj, 0.375, 25, 25);
	glPopMatrix();
	glEndList();

	glNewList(55, GL_COMPILE); //walls
	glPushMatrix();
	glutSolidCube(8);
	glPopMatrix();
	glEndList();

	glNewList(9, GL_COMPILE); //small walls
	glPushMatrix();
	glColor3f(0.949, 0.8588, 0.7765);
	glTranslatef(0, 2, -1.5);
	glRotatef(90, 1.0f, 0.0f, 0.0f);
	glRotatef(90, 0.0f, 0.0f, 1.0f);
	glScalef(1.0f, 0.01f, 1.0f);
	glutSolidCube(8);
	glPopMatrix();
	glEndList();

}
int back, front, left, right, top, grass;
int adidas, aramco, mastercard, ps5, airway, supra, emirates, continental;
int barca;
int screen1, screen2, screen3, screen4;
char backpath[] = "textures\\Skybox\\Daylight Box_Back.bmp";
char frontPath[] = "textures\\Skybox\\Daylight Box_Front.bmp";
char rightPath[] = "textures\\Skybox\\Daylight Box_Right.bmp";
char leftPath[] = "textures\\Skybox\\Daylight Box_Left.bmp";
char grassPath[] = "textures\\grass.bmp";
char topPath[] = "textures\\Skybox\\Daylight Box_Top.bmp";

char adidasPath[] = "textures\\logos\\Adidas.bmp";
char aramcoPath[] = "textures\\logos\\Aramco.bmp";
char masterPath[] = "textures\\logos\\MasterCard.bmp";
char ps5Path[] = "textures\\logos\\PS5.bmp";
char airwayPath[] = "textures\\logos\\QatarAirways.bmp";
char supraPath[] = "textures\\logos\\Supar.bmp";
char emiratesPath[] = "textures\\logos\\Emirates.bmp";
char continentalPath[] = "textures\\logos\\Continental.bmp";
char barcaPath[] = "textures\\logos\\Barca.bmp";
char screen1Path[] = "textures\\logos\\screen1.bmp";
char screen2Path[] = "textures\\logos\\screen2.bmp";
char screen3Path[] = "textures\\logos\\screen3.bmp";
char screen4Path[] = "textures\\logos\\screen4.bmp";


//void door(int a)
//{
//	auto_door1--;
//	auto_door2++;
//
//	if (auto_door1 == 109)
//	{
//		auto_door1 = 117;
//		auto_door2 = 125;
//	}
//	if (q == 0)
//	{
//		pbd = 0;
//		pbdhz = 0;
//		pbdhx = 0;
//
//		dangle = 0;
//
//		prdz = 0;
//		prdx = 0;
//		prhdz = 0;
//		prhdx = 0;
//
//		edx = 0;
//		edz = 0;
//
//		cdx = 0;
//		cdz = 0;
//
//		scrdz = 0;
//		scrdx = 0;
//
//		scrdzz = 0;
//		scrdxx = 0;
//	}
//	if (q == 1)
//	{
//		pbd = 3;
//		pbdhz = 5;
//		pbdhx = 5;
//
//		dangle = 90;
//
//		prdz = -3;
//		prdx = 3;
//		prhdz = -5;
//		prhdx = 5;
//
//		edx = 4;
//		edz = 14;
//
//		cdx = -111;
//		cdz = 99;
//
//		scrdz = 184;
//		scrdx = -130.2;
//
//		scrdzz = 6;
//		scrdxx = 41.2;
//	}
//
//	glutPostRedisplay();
//	glutTimerFunc(350, door, 0);
//}




void InitGL(void)
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_BLEND);									//enable blending 
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);  //enable blinding // Enable Smooth Shading
	glClearColor(0.396f, 0.619f, 0.78f, 1.0f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

	createFlag();
	createNet();
	createBunch();
	createSubseat();
	create_office();
	create_abmcar();
	createreception();
	create();
	createstages();

	glEnable(GL_TEXTURE_2D);
	back = LoadTexture(backpath, 255);
	front = LoadTexture(frontPath, 255);
	left = LoadTexture(leftPath, 255);
	right = LoadTexture(rightPath, 255);
	top = LoadTexture(topPath, 255);
	grass = LoadTexture(grassPath, 255);

	adidas = LoadTexture(adidasPath, 255);
	aramco = LoadTexture(aramcoPath, 255);
	mastercard = LoadTexture(masterPath, 255);
	ps5 = LoadTexture(ps5Path, 255);
	airway = LoadTexture(airwayPath, 255);
	supra = LoadTexture(supraPath, 255);
	emirates = LoadTexture(emiratesPath, 255);
	continental = LoadTexture(continentalPath, 255);

	barca = LoadTexture(barcaPath, 255);
	screen1 = LoadTexture(screen1Path, 255);
	screen2 = LoadTexture(screen2Path, 255);
	screen3 = LoadTexture(screen3Path, 255);
	screen4 = LoadTexture(screen4Path, 255);


	glNewList(655, GL_COMPILE);
	glPushMatrix();
	glScalef(6, 6, 6);
	GLUquadricObj* tree = gluNewQuadric();
	glPushMatrix();
	glColor3f(0.4, 0.2, 0.0);
	glTranslated(0, 7, 0);
	glRotated(90, 1, 0, 0);
	gluCylinder(tree, 1, 2, 12, 30, 30);
	glPopMatrix();
	glPushMatrix();
	glColor3ub(8, 66, 18);
	glTranslated(0, 14, 0);
	glRotated(90, 1, 0, 0);
	gluCylinder(tree, 0, 4, 10, 30, 30);
	glPopMatrix();
	glPopMatrix();
	glEndList();
}


void ReSizeGLScene(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)w / (GLfloat)h, 0.1f, 2600.0f);
	//gluOrtho2D(0, 100, 0, 100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void timer(int a) {
	glutPostRedisplay();
	glutTimerFunc(16, timer, 0);
	//th += 0.01;

}
//animation
GLfloat velocity = 1.1;
GLfloat p0 = 0;
GLfloat p1 = 50;
GLfloat p2 = 100;
GLfloat p3 = 150;
GLfloat p4 = 200;
GLfloat p5 = 250;
void Spine() {
	glutPostRedisplay();

	// Update position and check bounds for p0
	p0 += velocity;
	if ((p0 <= 0 && velocity < 0) || (p0 >= 310 && velocity > 0)) {
		velocity = -velocity; // reverse direction of motion
		p0 += 2 * velocity; // correct position after reversal
	}

	// Update position and check bounds for p1
	p1 += velocity;
	if ((p1 <= 50 && velocity < 0) || (p1 >= 310 && velocity > 0)) {
		velocity = -velocity; // reverse direction of motion
		p1 += 2 * velocity; // correct position after reversal
	}

	// Update position and check bounds for p2
	p2 += velocity;
	if ((p2 <= 100 && velocity < 0) || (p2 >= 310 && velocity > 0)) {
		velocity = -velocity; // reverse direction of motion
		p2 += 2 * velocity; // correct position after reversal
	}

	// Update position and check bounds for p3
	p3 += velocity;
	if ((p3 <= 150 && velocity < 0) || (p3 >= 310 && velocity > 0)) {
		velocity = -velocity; // reverse direction of motion
		p3 += 2 * velocity; // correct position after reversal
	}

	// Update position and check bounds for p4
	p4 += velocity;
	if ((p4 <= 200 && velocity < 0) || (p4 >= 310 && velocity > 0)) {
		velocity = -velocity; // reverse direction of motion
		p4 += 2 * velocity; // correct position after reversal
	}
}



void Camera() {
	targetPosX = cameraPosX - sin(horizontalAngle);
	targetPosZ = cameraPosZ - cos(horizontalAngle);
	targetPosY = cameraPosY - sin(verticalAngle);

	gluLookAt(cameraPosX, cameraPosY, cameraPosZ, targetPosX, targetPosY, targetPosZ, 0, 1, 0);
}

//drawing functions
void drawSkybox()
{
	glBindTexture(GL_TEXTURE_2D, front);
	glBegin(GL_QUADS);

	glTexCoord2d(0, 0);  glVertex3d(-skyboxsize, -skyboxsize, -skyboxsize);

	glTexCoord2d(1, 0);  glVertex3d(skyboxsize, -skyboxsize, -skyboxsize);

	glTexCoord2d(1, 1);  glVertex3d(skyboxsize, skyboxsize, -skyboxsize);

	glTexCoord2d(0, 1);  glVertex3d(-skyboxsize, skyboxsize, -skyboxsize);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, back);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-skyboxsize, -skyboxsize, skyboxsize);

	glTexCoord2d(1, 0);  glVertex3d(skyboxsize, -skyboxsize, skyboxsize);

	glTexCoord2d(1, 1);  glVertex3d(skyboxsize, skyboxsize, skyboxsize);

	glTexCoord2d(0, 1);  glVertex3d(-skyboxsize, skyboxsize, skyboxsize);
	glEnd();


	glBindTexture(GL_TEXTURE_2D, left);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-skyboxsize, -skyboxsize, skyboxsize);

	glTexCoord2d(1, 0);  glVertex3d(-skyboxsize, -skyboxsize, -skyboxsize);

	glTexCoord2d(1, 1);  glVertex3d(-skyboxsize, +skyboxsize, -skyboxsize);

	glTexCoord2d(0, 1);  glVertex3d(-skyboxsize, skyboxsize, skyboxsize);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, right);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(skyboxsize, -skyboxsize, skyboxsize);

	glTexCoord2d(1, 0);  glVertex3d(skyboxsize, -skyboxsize, -skyboxsize);

	glTexCoord2d(1, 1);  glVertex3d(skyboxsize, skyboxsize, -skyboxsize);

	glTexCoord2d(0, 1);  glVertex3d(skyboxsize, skyboxsize, skyboxsize);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, top);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-skyboxsize, skyboxsize, -skyboxsize);

	glTexCoord2d(1, 0);  glVertex3d(skyboxsize, skyboxsize, -skyboxsize);

	glTexCoord2d(1, 1);  glVertex3d(skyboxsize, skyboxsize, skyboxsize);

	glTexCoord2d(0, 1);  glVertex3d(-skyboxsize, skyboxsize, skyboxsize);
	glEnd();
}
void drawField() {
	glBindTexture(GL_TEXTURE_2D, grass);
	glBegin(GL_QUADS);

	glTexCoord2d(0, 0);  glVertex3d(-field_length, 0, -field_width);

	glTexCoord2d(20, 0);  glVertex3d(field_length, 0, -field_width);

	glTexCoord2d(20, 20);  glVertex3d(field_length, 0, field_width);

	glTexCoord2d(0, 20);  glVertex3d(-field_length, 0, field_width);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer




	glColor3f(1.0f, 1.0f, 1.0f); // Set line color to white
	glLineWidth(15.0f);


	// Draw boundary lines
	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glScalef(0.99, 0.99, 0.99);
	glBegin(GL_LINE_LOOP);
	glVertex2f(-field_length, -field_width);
	glVertex2f(field_length, -field_width);
	glVertex2f(field_length, field_width);
	glVertex2f(-field_length, field_width);
	glEnd();

	// Draw center line
	glBegin(GL_LINES);
	glVertex2f(0.0f, -field_width);
	glVertex2f(0.0f, field_width);
	glEnd();
	glPopMatrix();


	// Draw penalty areas
	glPushMatrix();
	glScalef(0.99, 0.99, 0.99);
	// Penalty area 1
	glBegin(GL_LINE_LOOP);
	glVertex3d(-field_length, 0, -goalAreaWidth);
	glVertex3d(-field_length + goalAreaLength, 0, -goalAreaWidth);
	glVertex3d(-field_length + goalAreaLength, 0, goalAreaWidth);
	glVertex3d(-field_length, 0, goalAreaWidth);
	glEnd();

	// Penalty area 2
	glBegin(GL_LINE_LOOP);
	glVertex3d(field_length, 0, -goalAreaWidth);
	glVertex3d(field_length - goalAreaLength, 0, -goalAreaWidth);
	glVertex3d(field_length - goalAreaLength, 0, goalAreaWidth);
	glVertex3d(field_length, 0, goalAreaWidth);
	glEnd();

	// Penalty area 3
	glBegin(GL_LINE_LOOP);
	glVertex3d(-field_length, 0, -penaltyAreaWidth);
	glVertex3d(-field_length + penaltyAreaLength, 0, -penaltyAreaWidth);
	glVertex3d(-field_length + penaltyAreaLength, 0, penaltyAreaWidth);
	glVertex3d(-field_length, 0, penaltyAreaWidth);
	glEnd();

	// Penalty area 4
	glBegin(GL_LINE_LOOP);
	glVertex3d(field_length, 0, -penaltyAreaWidth);
	glVertex3d(field_length - penaltyAreaLength, 0, -penaltyAreaWidth);
	glVertex3d(field_length - penaltyAreaLength, 0, penaltyAreaWidth);
	glVertex3d(field_length, 0, penaltyAreaWidth);
	glEnd();

	glPopMatrix();



	// Draw center disk and penalty spots
	glPushMatrix();
	glTranslatef(0, 0.1, 0);
	glRotatef(90, 1, 0, 0);

	// Draw center disk
	gluDisk(obj, 43.5f, 45.0f, 32, 1);
	gluDisk(obj, 0, 3.0f, 32, 1);

	// Draw penalty spots
	glPushMatrix();
	glTranslatef(field_length - 67.5, 0, 0);
	gluDisk(obj, 0, 2.0f, 32, 1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-field_length + 67.5, 0, 0);
	gluDisk(obj, 0, 2.0f, 32, 1);
	glPopMatrix();

	//draw palenty circles
	glPushMatrix();
	glTranslatef(-field_length + penaltyAreaLength, 0, 0);
	gluPartialDisk(obj, 28, 30, 50, 1, 0, 180);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(+field_length - penaltyAreaLength, 0, 0);
	gluPartialDisk(obj, 28, 30, 50, 1, 180, 180);
	glPopMatrix();

	// Draw corner arcs
	glScalef(0.99, 0.99, 0.99);

	glPushMatrix();
	glTranslatef(-field_length, -field_width, 0);
	gluPartialDisk(obj, 6, cornerRadius, 50, 1, 0, 90);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(field_length, -field_width, 0);
	glRotatef(180, 0, 0, 1);
	gluPartialDisk(obj, 6, cornerRadius, 50, 1, 90, 90);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(field_length, field_width, 0);
	gluPartialDisk(obj, 6, cornerRadius, 50, 1, 180, 90);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-field_length, field_width, 0);
	glRotatef(180, 0, 0, 1);
	gluPartialDisk(obj, 6, cornerRadius, 50, 1, 270, 90);
	glPopMatrix();

	glPopMatrix();



}
void drawFlags() {
	//four corner flags
	glPushMatrix();
	glTranslatef(field_length, 10, field_width);
	glRotatef(180, 0, 1, 0);
	glRotatef(frot, 0, 1, 0);
	glCallList(21);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(field_length, 10, -field_width);
	glRotatef(180, 0, 1, 0);
	glRotatef(frot, 0, 1, 0);
	glCallList(21);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-field_length, 10, field_width);
	glRotatef(frot, 0, 1, 0);
	glCallList(21);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-field_length, 10, -field_width);
	glRotatef(frot, 0, 1, 0);
	glCallList(21);
	glPopMatrix();
	frot += 1;//for rotating flages
}
void drawGoal() {
	//left goal post//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.5, 0.5, 24.4, 100, 100);
	glPopMatrix();

	//right goal post//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glTranslatef(73.2, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.5, 0.5, 24.4, 100, 100);
	glPopMatrix();

	//horizontal goal post//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(180, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.5, 0.5, 73.2, 100, 100);
	glPopMatrix();

	//horizontal top right post//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glTranslatef(73.2, 0, 0);
	glRotatef(180, 1, 0, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.5, 0.5, 15, 100, 100);
	glPopMatrix();

	//horizontal top left post//
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, -15);
	glRotatef(180, 1, 0, 0);
	glTranslatef(0, 0.5, 0);
	gluCylinder(obj, 0.5, 0.5, 15, 100, 100);
	glPopMatrix();
	//net//
	//use for loops to implement rows and columns//
	//consider them really thin cylinders//
	//use display list for rows and columns//
	//after doing that implement the entire goal in a display list, so we can have another goal post//

	//vertical back net lines//
	glPushMatrix();
	for (int i = 0; i < 26; i++)
	{
		glTranslatef(3, 0, 0);
		glCallList(1);
	}
	glPopMatrix();

	//horizontal back net lines//
	glPushMatrix();
	for (int i = 0; i < 8; i++)
	{
		glTranslatef(0, -3, 0);
		glCallList(2);
	}
	glPopMatrix();

	//left vertical net lines//
	glPushMatrix();
	for (int i = 0; i < 5; i++)
	{
		glTranslatef(0, 0, -3);
		glCallList(3);
	}
	glPopMatrix();





}
void drawBunch() {
	//chairs
	glPushMatrix();
	glTranslatef(-5, -5, -7);
	for (int i = 1; i <= 4; i++)
	{
		glTranslatef(7, 0, 0);
		glCallList(12);


	}

	glPopMatrix();

	//glass
	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	double eq11[4] = { 1.5, 1.1, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, eq11);
	double eq12[4] = { 1, 0, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, eq12);
	glColor4f(0.8, 0.8, 0.8, 0.8);
	gluCylinder(obj, 10, 10, 14.5, 100, 100);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();

	glPushMatrix();

	glTranslatef(14.5, 0, 0);
	for (int i = 1; i <= 1000; i++)
	{
		glTranslatef(0.001, 0, 0);
		glCallList(11);


	}

	glPopMatrix();

	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	glTranslatef(0, 0, 15.5);
	double eq13[4] = { 1.5, 1.1, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, eq13);
	double eq14[4] = { 1, 0, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, eq14);
	glColor4f(0.8, 0.8, 0.8, 0.8);
	gluCylinder(obj, 10, 10, 14.5, 100, 100);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();

	glPushMatrix();
	glColor4f(0.4, 0.4, 0.4, 1);
	glTranslatef(0, 9.5, 0);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0, 0);

	glVertex3d(30, 0, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0.5, 0.1);
	glVertex3d(30, 0, 0.1);

	glVertex3d(30, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 0.1);
	glVertex3d(30, 0.5, 0.1);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 0.1);
	glVertex3d(30, 0, 0.1);
	glVertex3d(30, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 0.1);
	glVertex3d(0, 0, 0.1);

	glVertex3d(0, 0, 0.1);
	glVertex3d(0, 0.5, 0.1);
	glVertex3d(30, 0.5, 0.1);
	glVertex3d(30, 0, 0.1);

	glEnd();
	glPopMatrix();


	//left side glass
	glPushMatrix();
	glColor4f(0.8, 0.8, 0.8, 0.8);
	glRotatef(-90, 0, 1, 0);
	gluPartialDisk(obj, 0, 10, 32, 32, 180, 180);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.05, 0, 0);
	for (int i = 1; i <= 200; i++)
	{
		glTranslatef(0.001, 0, 0);
		glCallList(11);


	}

	glPopMatrix();


	glPushMatrix();
	glColor4f(0.4, 0.4, 0.4, 1);
	glTranslatef(0.3, -7.5, 0);
	glRotatef(90, 0, 0, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(17.4, 0.3, 0);
	glVertex3d(17.4, 0, 0);

	glVertex3d(17.4, 0, 0);
	glVertex3d(17.4, 0.3, 0);
	glVertex3d(17.4, 0.3, 0.3);
	glVertex3d(17.4, 0, 0.3);

	glVertex3d(17.4, 0.3, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(17.4, 0.3, 0.3);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 0.3);
	glVertex3d(17.4, 0, 0.3);
	glVertex3d(17.4, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(0, 0, 0.3);

	glVertex3d(0, 0, 0.3);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(17.4, 0.3, 0.3);
	glVertex3d(17.4, 0, 0.3);

	glEnd();
	glPopMatrix();


	//right side glass
	glPushMatrix();
	glColor4f(0.8, 0.8, 0.8, 0.8);
	glRotatef(-90, 0, 1, 0);
	glTranslatef(0, 0, -30);
	gluPartialDisk(obj, 0, 10, 32, 32, 180, 180);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(29.95, 0, 0);
	for (int i = 1; i <= 200; i++)
	{
		glTranslatef(0.001, 0, 0);
		glCallList(11);


	}

	glPopMatrix();


	glPushMatrix();
	glColor4f(0.4, 0.4, 0.4, 1);
	glTranslatef(30, -7.5, 0);
	glRotatef(90, 0, 0, 1);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(17.4, 0.3, 0);
	glVertex3d(17.4, 0, 0);

	glVertex3d(17.4, 0, 0);
	glVertex3d(17.4, 0.3, 0);
	glVertex3d(17.4, 0.3, 0.3);
	glVertex3d(17.4, 0, 0.3);

	glVertex3d(17.4, 0.3, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(17.4, 0.3, 0.3);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 0.3);
	glVertex3d(17.4, 0, 0.3);
	glVertex3d(17.4, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.3, 0);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(0, 0, 0.3);

	glVertex3d(0, 0, 0.3);
	glVertex3d(0, 0.3, 0.3);
	glVertex3d(17.4, 0.3, 0.3);
	glVertex3d(17.4, 0, 0.3);

	glEnd();
	glPopMatrix();



	//floor
	glPushMatrix();
	glColor4f(0.4, 0.4, 0.4, 1);
	glTranslatef(0, -8, -6);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0, 0);

	glVertex3d(30, 0, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0.5, 6.7);
	glVertex3d(30, 0, 6.7);

	glVertex3d(30, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 6.7);
	glVertex3d(30, 0.5, 6.7);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 6.7);
	glVertex3d(30, 0, 6.7);
	glVertex3d(30, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 6.7);
	glVertex3d(0, 0, 6.7);

	glVertex3d(0, 0, 6.7);
	glVertex3d(0, 0.5, 6.7);
	glVertex3d(30, 0.5, 6.7);
	glVertex3d(30, 0, 6.7);

	glEnd();
	glPopMatrix();

}
void drawSubseat() {
	//Shader//
	glPushMatrix();
	double eq4[4] = { 1.5, 1.1, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, eq4);
	double eq5[4] = { 1, 0, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, eq5);
	glTranslatef(0, 0, -15);
	glColor4f(0.8, 0.8, 0.8, 0.5);
	gluCylinder(obj, 15, 15, 60, 100, 100);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();

	// left pole //
	glPushMatrix();
	glColor3f(0.827, 0.827, 0.827);
	glTranslatef(0, 0, -13);
	glTranslatef(0, 11.5, 0);
	glTranslatef(9, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 25, 100, 100);
	glPopMatrix();


	//right pole//
	glPushMatrix();
	glColor3f(0.827, 0.827, 0.827);
	glTranslatef(0, 0, 42);
	glTranslatef(0, 11.5, 0);
	glTranslatef(9, 0, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 25, 100, 100);
	glPopMatrix();


	//chairs base//
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(10.5, -9, 44);
	glRotatef(180, 0, 1, 0);
	glScalef(0.1, 0, 11.5);
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0, 0);

	glVertex3d(30, 0, 0);
	glVertex3d(30, 0.5, 0);
	glVertex3d(30, 0.5, 5);
	glVertex3d(30, 0, 5);

	glVertex3d(30, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(30, 0.5, 5);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 5);
	glVertex3d(30, 0, 5);
	glVertex3d(30, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 5);
	glVertex3d(0, 0, 5);

	glVertex3d(0, 0, 5);
	glVertex3d(0, 0.5, 5);
	glVertex3d(30, 0.5, 5);
	glVertex3d(30, 0, 5);

	glEnd();
	glPopMatrix();

	//chairs//
	glPushMatrix();
	glTranslatef(0, 0, -15);
	glTranslatef(0, -9, 0);
	glTranslatef(10, 0, 0);
	glRotatef(270, 0, 1, 0);

	for (int i = 1; i <= 8; i++)
	{
		glTranslatef(6, 0, 0);
		glCallList(4);
		if (i % 2 == 0)
		{
			glTranslatef(1, 0, 0);
			glCallList(5);
		}
		else
			continue;

	}
	glPopMatrix();

	//glass division//
	glPushMatrix();
	glTranslatef(0, 0, -15);
	glTranslatef(0, -9, 0);
	glTranslatef(10, 0, 0);
	glRotatef(270, 0, 1, 0);

	for (int i = 1; i <= 7; i++)
	{
		glTranslatef(6, 0, 0);
		if (i % 2 == 0)
		{
			glTranslatef(1, 0, 0);
			glCallList(6);
		}
	}
	glPopMatrix();
}
void drawBoarder() {
	glColor3f(1, 1, 1);
	gluCylinder(obj, 450.0f, 450.0f, 15.0f, 4, 32);
	glColor3f(0, 0, 0);
	gluCylinder(obj, 450.9f, 450.9f, 15.0f, 4, 32);

}

void drawAdidas() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, p0);
	glBindTexture(GL_TEXTURE_2D, adidas);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 7);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -7);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -7);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 7);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, p1);
	glBindTexture(GL_TEXTURE_2D, adidas);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 7);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -7);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -7);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 7);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, p2);
	glBindTexture(GL_TEXTURE_2D, adidas);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 7);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -7);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -7);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 7);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, p3);
	glBindTexture(GL_TEXTURE_2D, adidas);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 7);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -7);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -7);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 7);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, p4);
	glBindTexture(GL_TEXTURE_2D, adidas);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 7);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -7);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -7);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 7);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawQatar() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, -310 + p0);
	glBindTexture(GL_TEXTURE_2D, airway);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, -310 + p1);
	glBindTexture(GL_TEXTURE_2D, airway);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, -310 + p2);
	glBindTexture(GL_TEXTURE_2D, airway);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, -310 + p3);
	glBindTexture(GL_TEXTURE_2D, airway);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-328, 9, -310 + p4);
	glBindTexture(GL_TEXTURE_2D, airway);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawPs5() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, -310 + p0);
	glBindTexture(GL_TEXTURE_2D, ps5);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, -310 + p1);
	glBindTexture(GL_TEXTURE_2D, ps5);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, -310 + p2);
	glBindTexture(GL_TEXTURE_2D, ps5);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, -310 + p3);
	glBindTexture(GL_TEXTURE_2D, ps5);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, -310 + p4);
	glBindTexture(GL_TEXTURE_2D, ps5);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawMaster() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, p0);
	glBindTexture(GL_TEXTURE_2D, mastercard);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, p1);
	glBindTexture(GL_TEXTURE_2D, mastercard);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, p2);
	glBindTexture(GL_TEXTURE_2D, mastercard);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, p3);
	glBindTexture(GL_TEXTURE_2D, mastercard);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(308, 9, p4);
	glBindTexture(GL_TEXTURE_2D, mastercard);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);	glVertex3d(10, -5, -10);
	glTexCoord2d(1, 0);	glVertex3d(10, -5, 10);
	glTexCoord2d(1, 1); glVertex3d(10, 5, 10);
	glTexCoord2d(0, 1); glVertex3d(10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawSupra() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-323, 9, p0 - 311);
	glBindTexture(GL_TEXTURE_2D, supra);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(6, -6, 6);
	glTexCoord2d(1, 0);  glVertex3d(6, -6, -6);
	glTexCoord2d(1, 1);  glVertex3d(6, 6, -6);
	glTexCoord2d(0, 1);  glVertex3d(6, 6, 6);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-323, 9, p1 - 311);
	glBindTexture(GL_TEXTURE_2D, supra);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(6, -6, 6);
	glTexCoord2d(1, 0);  glVertex3d(6, -6, -6);
	glTexCoord2d(1, 1);  glVertex3d(6, 6, -6);
	glTexCoord2d(0, 1);  glVertex3d(6, 6, 6);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-323, 9, p2 - 311);
	glBindTexture(GL_TEXTURE_2D, supra);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(6, -6, 6);
	glTexCoord2d(1, 0);  glVertex3d(6, -6, -6);
	glTexCoord2d(1, 1);  glVertex3d(6, 6, -6);
	glTexCoord2d(0, 1);  glVertex3d(6, 6, 6);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-323, 9, p3 - 311);
	glBindTexture(GL_TEXTURE_2D, supra);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(6, -6, 6);
	glTexCoord2d(1, 0);  glVertex3d(6, -6, -6);
	glTexCoord2d(1, 1);  glVertex3d(6, 6, -6);
	glTexCoord2d(0, 1);  glVertex3d(6, 6, 6);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-323, 9, p4 - 311);
	glBindTexture(GL_TEXTURE_2D, supra);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(6, -6, 6);
	glTexCoord2d(1, 0);  glVertex3d(6, -6, -6);
	glTexCoord2d(1, 1);  glVertex3d(6, 6, -6);
	glTexCoord2d(0, 1);  glVertex3d(6, 6, 6);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawAramco() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-328, 9, p0);
	glBindTexture(GL_TEXTURE_2D, aramco);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-328, 9, p1);
	glBindTexture(GL_TEXTURE_2D, aramco);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-328, 9, p2);
	glBindTexture(GL_TEXTURE_2D, aramco);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-328, 9, p3);
	glBindTexture(GL_TEXTURE_2D, aramco);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-328, 9, p4);
	glBindTexture(GL_TEXTURE_2D, aramco);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -5, 10);
	glTexCoord2d(1, 0);  glVertex3d(10, -5, -10);
	glTexCoord2d(1, 1);  glVertex3d(10, 5, -10);
	glTexCoord2d(0, 1);  glVertex3d(10, 5, 10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawEmirates() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(328, 9, -310 + p0);
	glBindTexture(GL_TEXTURE_2D, emirates);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-10, -5, -10);
	glTexCoord2d(1, 0);  glVertex3d(-10, -5, 10);
	glTexCoord2d(1, 1);  glVertex3d(-10, 5, 10);
	glTexCoord2d(0, 1);  glVertex3d(-10, 5, -10);
	glEnd();
	glPopMatrix();




	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(328, 9, -310 + p1);
	glBindTexture(GL_TEXTURE_2D, emirates);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-10, -5, -10);
	glTexCoord2d(1, 0);  glVertex3d(-10, -5, 10);
	glTexCoord2d(1, 1);  glVertex3d(-10, 5, 10);
	glTexCoord2d(0, 1);  glVertex3d(-10, 5, -10);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(328, 9, -310 + p2);
	glBindTexture(GL_TEXTURE_2D, emirates);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-10, -5, -10);
	glTexCoord2d(1, 0);  glVertex3d(-10, -5, 10);
	glTexCoord2d(1, 1);  glVertex3d(-10, 5, 10);
	glTexCoord2d(0, 1);  glVertex3d(-10, 5, -10);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(328, 9, -310 + p3);
	glBindTexture(GL_TEXTURE_2D, emirates);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-10, -5, -10);
	glTexCoord2d(1, 0);  glVertex3d(-10, -5, 10);
	glTexCoord2d(1, 1);  glVertex3d(-10, 5, 10);
	glTexCoord2d(0, 1);  glVertex3d(-10, 5, -10);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(328, 9, -310 + p4);
	glBindTexture(GL_TEXTURE_2D, emirates);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-10, -5, -10);
	glTexCoord2d(1, 0);  glVertex3d(-10, -5, 10);
	glTexCoord2d(1, 1);  glVertex3d(-10, 5, 10);
	glTexCoord2d(0, 1);  glVertex3d(-10, 5, -10);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}
void drawcontinental() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(333, 9, p0);
	glBindTexture(GL_TEXTURE_2D, continental);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-15, -5, -15);
	glTexCoord2d(1, 0);  glVertex3d(-15, -5, 15);
	glTexCoord2d(1, 1);  glVertex3d(-15, 5, 15);
	glTexCoord2d(0, 1);  glVertex3d(-15, 5, -15);
	glEnd();
	glPopMatrix();




	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(333, 9, p1);
	glBindTexture(GL_TEXTURE_2D, continental);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-15, -5, -15);
	glTexCoord2d(1, 0);  glVertex3d(-15, -5, 15);
	glTexCoord2d(1, 1);  glVertex3d(-15, 5, 15);
	glTexCoord2d(0, 1);  glVertex3d(-15, 5, -15);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(333, 9, p2);
	glBindTexture(GL_TEXTURE_2D, continental);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-15, -5, -15);
	glTexCoord2d(1, 0);  glVertex3d(-15, -5, 15);
	glTexCoord2d(1, 1);  glVertex3d(-15, 5, 15);
	glTexCoord2d(0, 1);  glVertex3d(-15, 5, -15);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(333, 9, p3);
	glBindTexture(GL_TEXTURE_2D, continental);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-15, -5, -15);
	glTexCoord2d(1, 0);  glVertex3d(-15, -5, 15);
	glTexCoord2d(1, 1);  glVertex3d(-15, 5, 15);
	glTexCoord2d(0, 1);  glVertex3d(-15, 5, -15);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 1, 0);
	glTranslatef(333, 9, p4);
	glBindTexture(GL_TEXTURE_2D, continental);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(-15, -5, -15);
	glTexCoord2d(1, 0);  glVertex3d(-15, -5, 15);
	glTexCoord2d(1, 1);  glVertex3d(-15, 5, 15);
	glTexCoord2d(0, 1);  glVertex3d(-15, 5, -15);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
}

void drawBarca() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 0, 1);
	glTranslatef(0, 335, 0);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(0, -16, 320);
	glTexCoord2d(1, 0);  glVertex3d(0, -16, -320);
	glTexCoord2d(1, 1);  glVertex3d(0, 34, -320);
	glTexCoord2d(0, 1);  glVertex3d(0, 34, 320);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(-90, 0, 0, 1);
	glTranslatef(0, 335, 0);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(0, -16, -320);
	glTexCoord2d(1, 0); glVertex3d(0, -16, 320);
	glTexCoord2d(1, 1);    glVertex3d(0, 34, 320);
	glTexCoord2d(0, 1); glVertex3d(0, 34, -320);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 0, 1);
	glTranslatef(0, 0, 335);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(0, -370, -16);
	glTexCoord2d(1, 0);   glVertex3d(0, 370, -16);
	glTexCoord2d(1, 1); glVertex3d(0, 370, 34);
	glTexCoord2d(0, 1);   glVertex3d(0, -370, 34);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glRotatef(90, 0, 0, 1);
	glTranslatef(0, 0, -353);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(0, 370, 34);
	glTexCoord2d(1, 0);    glVertex3d(0, -370, 34);
	glTexCoord2d(1, 1);  glVertex3d(0, -370, -16);
	glTexCoord2d(0, 1); glVertex3d(0, 370, -16);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

}

void drawBanners() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(505, 295, -60);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -8, 400);
	glTexCoord2d(1, 0);  glVertex3d(10, -8, -400);
	glTexCoord2d(1, 1);  glVertex3d(10, 8, -400);
	glTexCoord2d(0, 1);  glVertex3d(10, 8, 400);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(445, 175, -60);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -8, 350);
	glTexCoord2d(1, 0);  glVertex3d(10, -8, -350);
	glTexCoord2d(1, 1);  glVertex3d(10, 8, -350);
	glTexCoord2d(0, 1);  glVertex3d(10, 8, 350);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-525, 295, 60);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -8, -400);
	glTexCoord2d(1, 0);  glVertex3d(10, -8, 400);
	glTexCoord2d(1, 1);  glVertex3d(10, 8, 400);
	glTexCoord2d(0, 1);  glVertex3d(10, 8, -400);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer
	
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-465, 175, 60);
	glBindTexture(GL_TEXTURE_2D, barca);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);  glVertex3d(10, -8, -350);
	glTexCoord2d(1, 0);  glVertex3d(10, -8, 350);
	glTexCoord2d(1, 1);  glVertex3d(10, 8, 350);
	glTexCoord2d(0, 1);  glVertex3d(10, 8, -350);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	


}

void draw_sides_2() {
	glPushMatrix();
	glTranslatef(0, 0, 20);

	glPushMatrix();//المدرجات
	glTranslatef(-150, 44, -18);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 11; j++) {
		for (int i = 0; i < 53; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-318, 2.9, -5);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-80, 50, -23);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 17; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-170, 6, -11);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-150, 73, -67);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 320; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-320, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-150, 73, -77);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 320; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-320, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-132, 93, -95);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 46; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-276, 0, 6);
	}
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-54, 99, -48);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea4 = gluNewQuadric();
	gluCylinder(fencea4, 0.6, 0.6, 175, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-54, 101, -48);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a4 = gluNewQuadric();
	gluCylinder(fence1a4, 0.6, 0.6, 175, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-54, 101, -48);
	for (int i = 0; i < 15; i++) {
		glCallList(33);
		glTranslatef(12.5, 0, 0);
	}

	glPopMatrix();

	glPushMatrix();//المدرجات

	glTranslatef(-150, 100, -60);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 14; j++) {
		for (int i = 0; i < 59; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}

		glTranslatef(-354, 2.8, -6);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-60, 106, -66);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 17; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-170, 5, -11);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-200, 139.5, -131);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 396; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-396, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-200, 138, -141);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 396; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-396, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-185, 159.5, -141);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 70; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-420, 0, 6);
	}
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-54, 165.5, -89);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea5 = gluNewQuadric();
	gluCylinder(fencea5, 0.6, 0.6, 240, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-54, 167.5, -89);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a5 = gluNewQuadric();
	gluCylinder(fence1a5, 0.6, 0.6, 240, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-54, 167.5, -89);
	for (int i = 0; i < 21; i++) {
		glCallList(33);
		glTranslatef(12, 0, 0);
	}

	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-172, 165, -115);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 9; j++) {
		for (int i = 0; i < 63; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-378, 2.8, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-60, 172, -122);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 3; j++) {
		for (int i = 0; i < 21; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-210, 5, -11);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-172, 191.5, -160);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 395; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-395, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-172, 190, -170);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 395; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-395, 1, 0);
	}
	glPopMatrix();
	glPopMatrix();
}
void draw_sides() {
	glPushMatrix();

	//the block
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 9; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-54, 3, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(0, 22, 2);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea6 = gluNewQuadric();
	gluCylinder(fencea6, 0.6, 0.6, 25, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(0, 24, 2);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a6 = gluNewQuadric();
	gluCylinder(fence1a6, 0.6, 0.6, 25, 40, 40);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(0, 24, 2);
	for (int i = 0; i < 3; i++) {
		glCallList(33);
		glTranslatef(12.5, 0, 0);
	}

	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-90, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 19; j++) {
		for (int i = 0; i < 24; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-144, 2.9, -5);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(0, 25, -6);
	glScalef(1.2, 1.2, 1);
	for (int j = 3; j < 10; j++) {
		for (int i = 0; i < j; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-j * 11.2, 6, -12);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-100, 73, -85);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 152; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-152, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-100, 73, -95);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 152; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-152, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-90, 93, -95);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 24; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-144, 0, 6);
	}
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-50, 98, -40);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea7 = gluNewQuadric();
	gluCylinder(fencea7, 0.6, 0.6, 90, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-50, 100, -40);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a7 = gluNewQuadric();
	gluCylinder(fence1a7, 0.6, 0.6, 90, 40, 40);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-50, 100, -40);
	for (int i = 0; i < 9; i++) {
		glCallList(33);
		glTranslatef(11.25, 0, 0);
	}

	glPopMatrix();
	glPushMatrix();//المدرجات

	glTranslatef(-163, 99, -60);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 14; j++) {
		for (int i = 0; i < 36; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}

		glTranslatef(-216, 2.8, -6);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-70, 105, -66);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 6; j++) {
		for (int i = 0; i < 9; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-90, 4.8, -12);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-145, 138, -131);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 196; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-196, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-145, 138, -141);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 196; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-196, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-135, 158, -141);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-192, 0, 6);
	}
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-110, 164, -93);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea8 = gluNewQuadric();
	gluCylinder(fencea8, 0.6, 0.6, 155, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-110, 166, -93);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a8 = gluNewQuadric();
	gluCylinder(fence1a8, 0.6, 0.6, 155, 40, 40);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-110, 166, -93);
	for (int i = 0; i < 14; i++) {
		glCallList(33);
		glTranslatef(11.923, 0, 0);
	}

	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-171, 164, -115);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 9; j++) {
		for (int i = 0; i < 38; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-228, 2.8, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-100, 170, -121);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 13; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-130, 4.8, -12);
	}

	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-175, 190, -160);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 230; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-230, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-175, 190, -170);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 230; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-230, 1, 0);
	}
	glPopMatrix();
}
void draw_straight_side() {
	glPushMatrix();

	//the block
	glTranslatef(-30, 0, 0);
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-20, 22, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea = gluNewQuadric();
	gluCylinder(fencea, 0.6, 0.6, 106, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-20, 24, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a = gluNewQuadric();
	gluCylinder(fence1a, 0.6, 0.6, 106, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-20, 24, 3);
	for (int i = 0; i < 21; i++) {
		glCallList(33);
		glTranslatef(5.3, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-48, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 23; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-138, 3.2, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-20, 22, -2.9);
	glScalef(1.2, 1.2, 1);
	glScalef(0.33, 1, 1);
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 25; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-250, 5.2, -11.7);
	}
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-40, 73, -75);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 160; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-160, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-42, 74, -84);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 165; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-165, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-38.5, 92, -84);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 27; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-162, 0, 6);
	}
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-25, 99, -34);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea2 = gluNewQuadric();
	gluCylinder(fencea, 0.6, 0.6, 116, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-25, 101, -34);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a2 = gluNewQuadric();
	gluCylinder(fence1a, 0.6, 0.6, 116, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-25, 101, -34);
	for (int i = 0; i < 23; i++) {
		glCallList(33);
		glTranslatef(5.27, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-70, 98, -50);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 13; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}

		glTranslatef(-192, 3.1, -6);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-30, 104, -56);
	glScalef(1.2, 1.2, 1);
	glScalef(0.33, 1, 1);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-320, 5.2, -11.7);
	}
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-65, 138, -105);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 183; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-183, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-65, 138.5, -115);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 183; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-183, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-65, 156, -115);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 34; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-204, 0, 6);
	}glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-33, 163, -65);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fencea3 = gluNewQuadric();
	gluCylinder(fencea3, 0.6, 0.6, 132, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-33, 165, -65);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1a3 = gluNewQuadric();
	gluCylinder(fence1a3, 0.6, 0.6, 132, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-33, 165, -65);
	for (int i = 0; i < 26; i++) {
		glCallList(33);
		glTranslatef(5.28, 0, 0);
	}

	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-102, 162, -100);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 9; j++) {
		for (int i = 0; i < 37; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}

		glTranslatef(-222, 3.1, -6);

	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-40, 168, -104);
	glScalef(1.2, 1.2, 1);
	glScalef(0.33, 1, 1);
	for (int j = 0; j < 3; j++) {
		for (int i = 0; i < 37; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-370, 5.2, -11.7);
	}
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-80, 190, -131);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 198; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-198, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-85, 190.5, -141);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 198; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-198, 1, 0);
	}
	glPopMatrix();
	glTranslatef(119, -2, 0);

}

void draw_stairs_2_floor() {
	glPushMatrix();//the stairs

	glTranslatef(-16, 16, -8);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 21; j++) {
		for (int i = 0; i < 3; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-18, 2, -4);
	}
	glEnd();
	glPopMatrix();
}
void draw_stairs_3_floor() {
	glPushMatrix();//the stairs

	glTranslatef(-16, 16, -8);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 14; j++) {
		for (int i = 0; i < 3; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-18, 2, -4);
	}
	glEnd();
	glPopMatrix();
}
void draw_st_2_floor() {
	glPushMatrix();//المدرجات
	glTranslatef(0, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 15; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}

		glTranslatef(-120, 3, -6);

	}
	glPopMatrix();

}
void draw_st_3_floor() {
	glPushMatrix();//المدرجات
	glTranslatef(0, 18, -40);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, -6);
	}
	glEnd();
	glPopMatrix();
}
void draw_stands() {
	glPushMatrix();
	glTranslatef(0, 0, -100);
	glPushMatrix();
	//first part
	//the block
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(0, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(0, 24, -6);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 9; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glPushMatrix();//the stairs
	glTranslatef(-17, 0, 12);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 4; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-16, 4, -4);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//the stairs

	glTranslatef(-16, 16, -8);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 28; j++) {
		for (int i = 0; i < 3; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-18, 2, -4);
	}
	glEnd();
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-10, 3, -101);
	glutSolidCube(13);
	glPopMatrix();
	//the second part
	glPushMatrix();
	glTranslatef(-135, 0, -100);
	glPushMatrix();
	//the block
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 7; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-42, 3, 0);
	}
	glPopMatrix();
	//the block
	glPushMatrix();
	glTranslatef(78, 0, 0);
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 7; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-42, 3, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(0, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 7; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-42, 3, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(78, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 7; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-42, 3, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(42, 30, -24);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 16; j++) {
		for (int i = 0; i < 7; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-42, 3, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(0, 30, -18);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glPushMatrix();//chairs left
	glTranslatef(0, 24, -6);
	glScalef(1.2, 1.2, 1);
	for (int i = 0; i < 3; i++) {
		glCallList(4);
		glTranslatef(10, 0, 0);

	}
	glPopMatrix();
	glPushMatrix();//chairs right
	glTranslatef(84, 24, -6);
	glScalef(1.2, 1.2, 1);
	for (int i = 0; i < 3; i++) {
		glCallList(4);
		glTranslatef(10, 0, 0);

	}
	glPopMatrix();
	glPushMatrix();//المدخل
	glTranslatef(39, 27, 3);
	glColor3f(0, 0.498, 0.8706);
	for (int j = 0; j < 28; j++) {
		for (int i = 0; i < 38; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-38, 0, -1);
	}

	glPopMatrix();
	glPushMatrix();//المدخل
	glTranslatef(39, -3, 3);
	glRotatef(90, 0, 0, 1);
	glColor3f(0, 0.498, 0.8706);
	for (int j = 0; j < 27; j++) {
		for (int i = 0; i < 30; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-30, 0, -1);
	}

	glPopMatrix();
	glPushMatrix();//المدخل
	glTranslatef(75, 26, 3);
	glRotatef(90, 0, 0, -1);
	glColor3f(0, 0.498, 0.8706);
	for (int j = 0; j < 27; j++) {
		for (int i = 0; i < 30; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-30, 0, -1);
	}

	glPopMatrix();
	//third part
	glPushMatrix();
	//first part
	//the block
	glTranslatef(-135, 0, 0);
	glColor3f(0.949, 0.8588, 0.7765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//المدرجات
	glTranslatef(-135, 18, 0);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 20; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-120, 3, -6);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-135, 24, -6);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 2; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glPushMatrix();//chairs
	glTranslatef(-40, 36, -30);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 6; j++) {
		for (int i = 0; i < 2; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-20, 5, -12);
	}
	glPopMatrix();
	glPushMatrix();//the stairs
	glTranslatef(-17, 0, 12);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 4; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-16, 4, -4);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//the stairs

	glTranslatef(-16, 16, -8);
	glColor3f(0.8902, 0.1765, 0.1765);
	for (int j = 0; j < 28; j++) {
		for (int i = 0; i < 3; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-18, 2, -4);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-12, 3, 0);
	glutSolidCube(13);
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-137.5, 73, -115);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 390; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-390, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-137.5, 73, -133);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//wall2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(0, 73, -133);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//wall3
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(137.5, 73, -133);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 115; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-115, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-134.5, 93, -130);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 65; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-390, 0, 6);
	}
	glPopMatrix();
	//secound floor
	glPushMatrix();//مدرجات
	glTranslatef(0, 81, -96);
	draw_st_2_floor();
	glPushMatrix();//chairs
	glTranslatef(0, 21, 0);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 7; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glTranslatef(-134, 0, 0);
	draw_st_2_floor();
	glPushMatrix();//chairs
	glTranslatef(80, 21, 0);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 7; j++) {
		for (int i = 0; i < 3; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-30, 5, -12);
	}
	glPopMatrix();
	glTranslatef(268, 0, 0);
	draw_st_2_floor();
	glPushMatrix();//chairs
	glTranslatef(0, 21, 0);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 7; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//stairs
	glTranslatef(0, 81, -90);
	draw_stairs_2_floor();
	glTranslatef(132, 0, 0);
	draw_stairs_2_floor();
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-137.5, 139, -199);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();

	glPushMatrix();//wall2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(0, 139, -199);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//wall3
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(136.5, 139, -199);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 115; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-115, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-138.5, 138.5, -182);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 390; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-390, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//roof
	glColor3f(0.8902, 0.8078, 0.8823);
	glTranslatef(-134.5, 158, -197);
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 65; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-390, 0, 6);
	}
	glPopMatrix();
	//third floor
	glPushMatrix();//مدرجات
	glTranslatef(-135, 146, -125);
	draw_st_3_floor();
	glPushMatrix();//chairs
	glTranslatef(70, 21, -40);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 4; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-40, 5, -12);
	}
	glPopMatrix();
	glTranslatef(270, 0, 0);
	draw_st_3_floor();
	glPushMatrix();//chairs
	glTranslatef(0, 21, -40);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < 10; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-100, 5, -12);
	}
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//فوق مدرج نصفي
	glTranslatef(0, 18, -40);
	glTranslatef(3, 164, -161);
	glColor3f(0.6902, 0.6823, 0.7294);
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 19; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-114, 3, -6);
	}
	glEnd();
	glPushMatrix();//chairs
	glTranslatef(0, -6, 20);
	glScalef(1.2, 1.2, 1);
	for (int j = 0; j < 2; j++) {
		for (int i = 0; i < 9; i++) {
			glCallList(4);
			glTranslatef(10, 0, 0);
		}
		glTranslatef(-90, 5, -12);
	}
	glPopMatrix();
	glPopMatrix();

	glPushMatrix();//stairs
	glTranslatef(1, 147, -157);
	draw_stairs_3_floor();
	glTranslatef(132, 0, 0);
	draw_stairs_3_floor();
	glTranslatef(-70, 23, -33);
	glPopMatrix();
	glPushMatrix();//floor
	glColor3f(0.8902, 0.1765, 0.1765);
	glTranslatef(-138.5, 190, -220.5);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 390; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-390, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//wall1
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-137.5, 190, -238.5);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//wall2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(0, 190, -238.5);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 110; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-110, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//wall3
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(136.5, 190, -238.5);
	for (int j = 0; j < 18; j++) {
		for (int i = 0; i < 115; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-115, 1, 0);
	}
	glPopMatrix();
	glPushMatrix();//inner floor
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-37, 70, -135.5);
	for (int j = 0; j < 25; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-192, 0, -6);
	}
	glPopMatrix();
	glPushMatrix();//inner stairs1
	glTranslatef(0, 113, -248);
	glRotatef(180, 0, 1, 0);
	glColor3f(0, 0, 0.6);
	for (int j = 0; j < 13; j++) {
		for (int i = 0; i < 8; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-32, 2, -4);
	}
	glPopMatrix();
	glPushMatrix();//stairs floor
	glTranslatef(-30, 110.5, -248);
	glColor3f(0.4, 0, 0);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 80; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-80, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//st2
	glTranslatef(20, 76, -184);
	glColor3f(0, 0, 0.6);
	for (int j = 0; j < 17; j++) {
		for (int i = 0; i < 8; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-32, 2, -4);
	}
	glPopMatrix();
	glPushMatrix();//walls
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-30, 73, -134);
	for (int j = 0; j < 47; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//walls
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-30, 120, -155);
	for (int j = 0; j < 9; j++) {
		for (int i = 0; i < 90; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 90);
	}
	glPopMatrix();
	glPushMatrix();//walls
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(150, 73, -134);
	for (int j = 0; j < 47; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//walls
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-37, 75, -280);
	for (int j = 0; j < 10; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-192, 6, 0);
	}
	glPopMatrix();
	glPushMatrix();//inner floor2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(5, 135, -202);
	for (int j = 0; j < 25; j++) {
		for (int i = 0; i < 25; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-150, 0, -6);
	}
	glPopMatrix();
	glPushMatrix();//inner stairs1
	glTranslatef(-2, 165, -285);
	glRotatef(180, 0, 1, 0);
	glColor3f(0, 0, 0.6);
	for (int j = 0; j < 13; j++) {
		for (int i = 0; i < 8; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-32, 2, -4);
	}
	glPopMatrix();
	glPushMatrix();//stairs floor
	glTranslatef(-31, 163, -287);
	glColor3f(0.4, 0, 0);
	for (int j = 0; j < 20; j++) {
		for (int i = 0; i < 80; i++) {
			glCallList(31);
			glTranslatef(1, 0, 0);
		}
		glTranslatef(-80, 0, -1);
	}
	glPopMatrix();
	glPushMatrix();//st2
	glTranslatef(20, 140, -240);
	glColor3f(0, 0, 0.6);
	for (int j = 0; j < 13; j++) {
		for (int i = 0; i < 8; i++) {
			glCallList(32);
			glTranslatef(4, 0, 0);
		}
		glTranslatef(-32, 2, -4);
	}
	glPopMatrix();
	glPushMatrix();//inner floor2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(3, 187.5, -241);
	for (int j = 0; j < 25; j++) {
		for (int i = 0; i < 25; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-150, 0, -6);
	}
	glPopMatrix();
	glPushMatrix();//walls2
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-30, 120, -199.5);
	for (int j = 0; j < 64; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//walls2
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(150, 120, -199.5);
	for (int j = 0; j < 64; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//walls2
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-37, 123, -348);
	for (int j = 0; j < 15; j++) {
		for (int i = 0; i < 32; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-192, 6, 0);
	}
	glPopMatrix();
	glPushMatrix();//walls3
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(-33, 173, -239);
	for (int j = 0; j < 36; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//walls3
	glColor3f(0.6588, 0.6588, 0.6588);
	glTranslatef(150, 173, -239);
	for (int j = 0; j < 36; j++) {
		for (int i = 0; i < 148; i++) {
			glCallList(31);
			glTranslatef(0, 0, -1);
		}
		glTranslatef(0, 1, 148);
	}
	glPopMatrix();
	glPushMatrix();//inner floor2
	glColor3f(0.2157, 0.2117, 0.251);
	glTranslatef(-31, 210, -241);
	for (int j = 0; j < 25; j++) {
		for (int i = 0; i < 33; i++) {
			glCallList(30);
			glTranslatef(6, 0, 0);
		}
		glTranslatef(-198, 0, -6);
	}
	glPopMatrix();
	glPushMatrix();//left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 22, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence = gluNewQuadric();
	gluCylinder(fence, 0.6, 0.6, 118, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 24, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence1 = gluNewQuadric();
	gluCylinder(fence1, 0.6, 0.6, 118, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(-137, 24, 3);
	for (int i = 0; i < 15; i++) {
		glCallList(33);
		glTranslatef(8.428, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();// middle fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 98, -74);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence2 = gluNewQuadric();
	gluCylinder(fence2, 0.6, 0.6, 390, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// middle fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 100, -74);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence3 = gluNewQuadric();
	gluCylinder(fence3, 0.6, 0.6, 390, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences middle
	glTranslatef(-137, 100, -74);
	for (int i = 0; i < 40; i++) {
		glCallList(33);
		glTranslatef(10, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();// upper fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 163, -154);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence4 = gluNewQuadric();
	gluCylinder(fence4, 0.6, 0.6, 390, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();// upper fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-137, 165, -154);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence5 = gluNewQuadric();
	gluCylinder(fence5, 0.6, 0.6, 390, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences upper
	glTranslatef(-137, 165, -154);
	for (int i = 0; i < 40; i++) {
		glCallList(33);
		glTranslatef(10, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();//middle left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-1, 22, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence6 = gluNewQuadric();
	gluCylinder(fence6, 0.6, 0.6, 39.5, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//middle left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(-1, 24, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence7 = gluNewQuadric();
	gluCylinder(fence7, 0.6, 0.6, 39.5, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences middle left
	glTranslatef(-1, 24, 3);
	for (int i = 0; i < 5; i++) {
		glCallList(33);
		glTranslatef(8.428, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();//middle right down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(75.5, 22, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence8 = gluNewQuadric();
	gluCylinder(fence8, 0.6, 0.6, 39.5, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//middle right down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(75.5, 24, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence9 = gluNewQuadric();
	gluCylinder(fence9, 0.6, 0.6, 39.5, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences middle right
	glTranslatef(115, 24, 3);
	for (int i = 0; i < 5; i++) {
		glCallList(33);
		glTranslatef(-8.428, 0, 0);
	}
	glPopMatrix();
	glPushMatrix();//left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(133, 22, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence10 = gluNewQuadric();
	gluCylinder(fence10, 0.6, 0.6, 118, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//left down fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(133, 24, 3);
	glRotatef(90, 1, 0, 0);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* fence11 = gluNewQuadric();
	gluCylinder(fence11, 0.6, 0.6, 118, 40, 40);
	glTranslatef(0, 0, -2);
	glPopMatrix();
	glPushMatrix();//fences
	glTranslatef(133, 24, 3);
	for (int i = 0; i < 15; i++) {
		glCallList(33);
		glTranslatef(8.428, 0, 0);
	}
	glEnd();
	glPopMatrix();
	glPushMatrix();//stairs fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(16, 120, -248);
	glRotatef(25, 1, 0, 0);
	GLUquadricObj* st_fence = gluNewQuadric();
	gluCylinder(st_fence, 0.6, 0.6, 80, 40, 40);
	glPopMatrix();
	glPushMatrix();//fencees st
	glTranslatef(16, 120, -248);
	int h = 46;
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < h; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h - 4.8, 10);
		h = h - 4;
	}
	glPopMatrix();
	glPushMatrix();//stairs fence2
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(50, 120, -248);
	glRotatef(25, 1, 0, 0);
	GLUquadricObj* st_fence1 = gluNewQuadric();
	gluCylinder(st_fence1, 0.6, 0.6, 80, 40, 40);
	glPopMatrix();
	glPushMatrix();//fencees st2
	glTranslatef(50, 120, -248);
	int h1 = 46;
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < h1; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h1 - 4.8, 10);
		h1 = h1 - 4;
	}
	glPopMatrix();
	glPushMatrix();//stairs fence11
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(18, 170, -278);
	glRotatef(25, 1, 0, 0);
	GLUquadricObj* st_fence2 = gluNewQuadric();
	gluCylinder(st_fence2, 0.6, 0.6, 52, 40, 40);
	glPopMatrix();
	glPushMatrix();//fencees st3
	glTranslatef(18, 170, -278);
	int h2 = 34;
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < h2; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h2 - 5.1, 11);
		h2 = h2 - 4;
	}
	glPopMatrix();
	glPushMatrix();//stairs fence11
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(50, 170, -278);
	glRotatef(25, 1, 0, 0);
	GLUquadricObj* st_fence3 = gluNewQuadric();
	gluCylinder(st_fence3, 0.6, 0.6, 52, 40, 40);
	glPopMatrix();
	glPushMatrix();//fencees st3
	glTranslatef(50, 170, -278);
	int h3 = 34;
	for (int j = 0; j < 5; j++) {
		for (int i = 0; i < h3; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h3 - 5.1, 11);
		h3 = h3 - 4;
	}
	glPopMatrix();
	glPushMatrix();//stairs fence
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(2, 120, -248);
	glRotatef(-25, 1, 0, 0);
	GLUquadricObj* st_fence4 = gluNewQuadric();
	gluCylinder(st_fence4, 0.6, 0.6, 40, 50, 40);
	glPopMatrix();
	glPushMatrix();//fencees st4
	glTranslatef(2, 120, -248);
	int h4 = 54;
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < h4; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h4 + 5.1, 11);
		h4 = h4 + 4;
	}
	glPopMatrix();
	glPushMatrix();//stairs fence5
	glColor3f(0.46, 0.45, 0.53);
	glTranslatef(5, 170, -280);
	glRotatef(-25, 1, 0, 0);
	GLUquadricObj* st_fence5 = gluNewQuadric();
	gluCylinder(st_fence5, 0.6, 0.6, 40, 50, 40);
	glPopMatrix();
	glPushMatrix();//fencees st5
	glTranslatef(5, 170, -280);
	int h5 = 37;
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < h5; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, h5 + 5.1, 11);
		h5 = h5 + 4;
	}
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(50, 120, -269);
	GLUquadricObj* st_fence6 = gluNewQuadric();
	gluCylinder(st_fence6, 0.6, 0.6, 21, 50, 40);
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(-25, 120, -269);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* st_fence7 = gluNewQuadric();
	gluCylinder(st_fence7, 0.6, 0.6, 75, 50, 40);
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(2, 120, -248);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* st_fence8 = gluNewQuadric();
	gluCylinder(st_fence8, 0.6, 0.6, 14, 50, 40);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//fencees sta
	glTranslatef(-85, 120, -367);
	for (int j = 0; j < 2; j++) {
		for (int i = 0; i < 49; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(0, 49, 12);
	}
	glPopMatrix();
	glPushMatrix();//fencees sta
	glTranslatef(-85, 120, -369);
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 49; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}
		glTranslatef(-10, 49, 0);
	}
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(-85, 170, -408.5);
	GLUquadricObj* st_fence9 = gluNewQuadric();
	gluCylinder(st_fence9, 0.6, 0.6, 30, 50, 40);
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(-155, 170, -408.5);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* st_fence10 = gluNewQuadric();
	gluCylinder(st_fence10, 0.6, 0.6, 70, 50, 40);
	glPopMatrix();
	glPushMatrix();//st_fl_fence
	glTranslatef(-130.5, 170, -378);
	glRotatef(90, 0, 1, 0);
	GLUquadricObj* st_fence11 = gluNewQuadric();
	gluCylinder(st_fence11, 0.6, 0.6, 14, 50, 40);
	glPopMatrix();
	glPushMatrix();//fencees sta
	glTranslatef(-85, 170, -408.5);
	for (int j = 0; j < 3; j++) {
		for (int i = 0; i < 49; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}

		glTranslatef(0, 49, 12);
	}
	glPopMatrix();
	glPushMatrix();//fencees sta
	glTranslatef(-85, 170, -408.5);
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 49; i++) {
			glCallList(31);
			glTranslatef(0, -1, 0);

		}

		glTranslatef(-8, 49, 0);
	}
	glPopMatrix();
	glPushMatrix();
	glTranslatef(119, 0, -96);
	glRotatef(-45, 0, 1, 0);
	draw_sides();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-265, -2, -60);
	glRotatef(45, 0, 1, 0);
	draw_sides_2();
	glPopMatrix();
	glPushMatrix();
	glScalef(1, 1, 3);
	glTranslatef(0, 0, 66);
	glPushMatrix();
	glTranslatef(140, 0, -70);
	glRotatef(-90, 0, 1, 0);
	draw_straight_side();
	glPopMatrix();
	glPopMatrix();

	glPopMatrix();
}
void draw_roof() {
	glPushMatrix();
	glTranslatef(0, 31, 0);
	glScalef(1.5, 1.5, 1.5);
	glPushMatrix();//1
	glTranslatef(roofmove, 0, 0);
	glBegin(GL_TRIANGLES);
	glColor3f(0.98, 0.98, 0.98);
	glVertex3f(0.0, 0, 0.0);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(40, -30, 210);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_QUADS);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(40, -30, 210);
	glEnd();
	glColor3f(0, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(68.9, 0, 166.3);
	glVertex3f(40, -30, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(68.9, -60, 166.3);
	glEnd();
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(-68.9, -60, 166.3);
	glEnd();
	glPopMatrix();
	glPushMatrix();//2
	glTranslatef(roofmove / 2, rooftop, roofmove);
	glRotatef(-45, 0, 1, 0);
	glBegin(GL_TRIANGLES);
	glColor3f(0.91, 0.91, 0.91);
	glVertex3f(0.0, 0, 0.0);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(40, -30, 210);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_QUADS);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(40, -30, 210);
	glEnd();
	glColor3f(0, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(68.9, 0, 166.3);
	glVertex3f(40, -30, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(68.9, -60, 166.3);
	glEnd();
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(-68.9, -60, 166.3);
	glEnd();
	glPopMatrix();
	glPushMatrix();//3
	glTranslatef(0, rooftop * 2, roofmove);
	glRotatef(-90, 0, 1, 0);
	glBegin(GL_TRIANGLES);
	glColor3f(0.98, 0.98, 0.98);
	glVertex3f(0.0, 0, 0.0);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(40, -30, 210);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_QUADS);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(40, -30, 210);
	glEnd();
	glColor3f(0, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(68.9, 0, 166.3);
	glVertex3f(40, -30, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(68.9, -60, 166.3);
	glEnd();
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(-68.9, -60, 166.3);
	glEnd();
	glPopMatrix();
	glPushMatrix();//4
	glTranslatef(-roofmove, rooftop * 3, roofmove / 2);
	glRotatef(-135, 0, 1, 0);
	glBegin(GL_TRIANGLES);
	glColor3f(0.91, 0.91, 0.91);
	glVertex3f(0.0, 0, 0.0);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(40, -30, 210);
	glVertex3f(68.9, 0, 166.3);
	glEnd();
	glColor3f(0.5, 0.5, 0.5);
	glBegin(GL_QUADS);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(40, -30, 210);
	glEnd();
	glColor3f(0, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(68.9, 0, 166.3);
	glVertex3f(40, -30, 210);
	glVertex3f(40, -60, 210);
	glVertex3f(68.9, -60, 166.3);
	glEnd();
	glBegin(GL_QUADS);
	glVertex3f(-68.9, 0, 166.3);
	glVertex3f(-40, -30, 210);
	glVertex3f(-40, -60, 210);
	glVertex3f(-68.9, -60, 166.3);
	glEnd();
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, -60, 0);
	glRotatef(90, 1, 0, 0);
	glColor3f(0.6, 0.851, 0.917);
	GLUquadricObj* circle = gluNewQuadric();
	gluDisk(circle, 270, 530, 40, 40);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, -60, 0);
	glScalef(1, 1, 1.5);
	glRotatef(90, 1, 0, 0);
	glColor3f(0.6, 0.851, 0.917);
	GLUquadricObj* circle1 = gluNewQuadric();
	gluDisk(circle, 340, 640, 60, 60);
	glPopMatrix();
	glPushMatrix();//shape2
	glTranslatef(0, -140, 0);
	glScalef(1, 0.4, 1);
	glPushMatrix();
	double ffa[4] = { 0, -1.0, 0.0,150 };

	double ff1a[4] = { 0, 1.0, 0.0,-30 };



	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ffa);
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, ff1a);

	glScalef(1, 1, 1.5);
	glColor3f(0.88, 0, 0);
	glutSolidSphere(687, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//shape3
	glTranslatef(0, -140, 0);
	glScalef(1, 0.4, 1);
	glPushMatrix();
	double ffa2[4] = { 0, -1.0, 0.0,-30 };

	double ff2a[4] = { 0, 1.0, 0.0,150 };



	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ffa2);
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, ff2a);

	glScalef(1, 1, 1.5);
	glColor3f(0.88, 0, 0);
	glutSolidSphere(687, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//shape
	glTranslatef(0, -140, 0);
	glScalef(1, 0.4, 1);
	glPushMatrix();
	double ff[4] = { 0, -1.0, 0.0,250 };

	double ff1[4] = { 0, 1.0, 0.0,250 };



	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ff);
	glEnable(GL_CLIP_PLANE1);
	glClipPlane(GL_CLIP_PLANE1, ff1);

	glScalef(1, 1, 1.5);
	glColor3f(0, 0.4, 0.7);
	glutSolidSphere(685, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glDisable(GL_CLIP_PLANE1);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();
	double ff2[4] = { 1, 0, 0,-120 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ff2);
	glTranslatef(0, -240, 0);
	glRotatef(90, 0, 1, 0);
	glPushMatrix();
	glScalef(1.5, 1, 1);
	glRotatef(90, 1, 0, 0);
	glColor3f(0, 0.4, 0.7);
	GLUquadricObj* sh = gluNewQuadric();
	gluCylinder(sh, 640, 640, 170, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//shapee
	double ff3[4] = { 1, 0, 0,-120 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ff3);
	glTranslatef(0, -260, 0);
	glRotatef(90, 0, 1, 0);
	glPushMatrix();
	glScalef(1.5, 1, 1);
	glRotatef(90, 1, 0, 0);
	glColor3f(1, 0.843, 0);
	GLUquadricObj* sh1 = gluNewQuadric();
	gluCylinder(sh1, 652, 652, 50, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();//shapee1
	double ff4[4] = { 1, 0, 0,-120 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ff4);
	glTranslatef(0, -335, 0);
	glRotatef(90, 0, 1, 0);
	glPushMatrix();
	glScalef(1.5, 1, 1);
	glRotatef(90, 1, 0, 0);
	glColor3f(1, 0.843, 0);
	GLUquadricObj* sh2 = gluNewQuadric();
	gluCylinder(sh2, 652, 652, 50, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glPopMatrix();
	glPopMatrix();

}

void drawCameras() {
	glNewList(13, GL_COMPILE);
	//legs
	glPushMatrix();
	glColor3f(0.2, 0.2, 0.2);
	glTranslatef(1, 6, 0);
	glRotatef(90, 1, 0, 0);
	gluCylinder(obj, 0.5, 0.5, 7, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.55, 0.55);
	glTranslatef(1, 3, 0);
	glRotatef(145, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.55, 0.55);
	glTranslatef(1, 0.15, 4);
	glRotatef(145, -1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.35, 0.35, 0.35);
	glTranslatef(1, 3, 0);
	glutSolidCube(1.1);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.55, 0.55);
	glTranslatef(0, 6, 0);
	glRotatef(125, 1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glTranslatef(1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glTranslatef(1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.55, 0.55);
	glTranslatef(0, 0.15, 4);
	glRotatef(125, -1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glTranslatef(1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glTranslatef(1, 0, 0);
	gluCylinder(obj, 0.25, 0.25, 7, 32, 32);
	glPopMatrix();

	//middle part
	glPushMatrix();
	glColor3f(0.9, 0.9, 0.9);
	glTranslatef(1, 6.5, 0);
	glScalef(2, 1, 1);
	glutSolidCube(1.5);
	glPopMatrix();

	//handles
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(2.6, 6.25, -0.9);
	gluCylinder(obj, 0.1, 0.1, 1.9, 32, 32);
	glPopMatrix();

	//right
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(1.2, 6.25, 0.9);
	glRotatef(90, 0, 1, 0);
	gluCylinder(obj, 0.1, 0.1, 1.4, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.3, 0.3, 0.3);
	glTranslatef(1, 6.25, 1);
	gluDisk(obj, 0, 0.25, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(1, 6.25, 1);
	gluCylinder(obj, 0.1, 0.1, 1, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(0, 7.25, 2);
	glRotatef(90, 0, 1, 0);
	glRotatef(45, 1, 0, 0);
	gluCylinder(obj, 0.1, 0.1, 1.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(-3, 7.25, 2);
	glRotatef(90, 0, 1, 0);
	gluCylinder(obj, 0.1, 0.1, 3, 32, 32);
	glPopMatrix();

	//left
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(1.2, 6.25, -0.9);
	glRotatef(90, 0, 1, 0);
	gluCylinder(obj, 0.1, 0.1, 1.4, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.3, 0.3, 0.3);
	glTranslatef(1, 6.25, -1);
	gluDisk(obj, 0, 0.25, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(1, 6.25, -2);
	gluCylinder(obj, 0.1, 0.1, 1, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(0, 7.25, -2);
	glRotatef(90, 0, 1, 0);
	glRotatef(45, 1, 0, 0);
	gluCylinder(obj, 0.1, 0.1, 1.5, 32, 32);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(-3, 7.25, -2);
	glRotatef(90, 0, 1, 0);
	gluCylinder(obj, 0.1, 0.1, 3, 32, 32);
	glPopMatrix();

	//top part
	glPushMatrix();
	glColor3f(0.8, 0.8, 0.8);
	glTranslatef(-1.5, 8, 0);
	glutSolidCube(2.5);
	glTranslatef(2.5, 0, 0);
	glutSolidCube(2.5);
	glTranslatef(2.5, 0, 0);
	glutSolidCube(2.5);
	glPopMatrix();

	glPushMatrix();
	double eq15[4] = { -1, 1.0, 0.0,0.0 };
	glEnable(GL_CLIP_PLANE0);
	glTranslatef(4.75, 8, 0);
	glClipPlane(GL_CLIP_PLANE0, eq15);
	glColor3f(0.8, 0.8, 0.8);
	glutSolidCube(2.5);
	glDisable(GL_CLIP_PLANE0);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0, 0, 0);
	glTranslatef(4.87, 9, 1.25);
	glRotatef(90, 0, 1, 0);
	glBegin(GL_QUADS);
	glVertex3d(0.1, 0.2, -0.1);
	glVertex3d(0.1, -2.2, -0.1);
	glVertex3d(2.4, -2.2, -0.1);
	glVertex3d(2.4, 0.2, -0.1);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor4f(0.9, 0.9, 0.9, 0.5);
	glTranslatef(4.88, 8, 0);
	glRotatef(90, 0, 1, 0);
	gluDisk(obj, 0, 0.7, 100, 100);
	for (int i = 0; i < 10; i++)
	{
		glTranslatef(0, 0, 0.01);
		gluDisk(obj, 0, 0.7, 100, 100);
	}
	glPopMatrix();

	glEndList();

	glPushMatrix();
	glTranslatef(-340, 0, 110);
	glScalef(3, 3, 3);
	glCallList(13);
	glTranslatef(0, 0, -80);
	glCallList(13);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-90, 0, 340);
	glRotatef(90, 0, 1, 0);
	glScalef(3, 3, 3);
	glCallList(13);
	glTranslatef(0, 0, 80);
	glCallList(13);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-110, 0, -340);
	glRotatef(90, 0, -1, 0);
	glScalef(3, 3, 3);
	glCallList(13);
	glTranslatef(0, 0, -80);
	glCallList(13);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(350, 0, -120);
	glRotatef(180, 0, 1, 0);
	glScalef(3, 3, 3);
	glCallList(13);
	glTranslatef(0, 0, -80);
	glCallList(13);
	glPopMatrix();
}


void draw_walkway() {
	//the block
	glPushMatrix();
	glColor3f(0.0000, 0.3020, 0.5961);
	glTranslatef(4, 2, -2);
	glRotatef(90, 1.0f, 0.0f, 0.0f);
	glScalef(3.0f, 0.01f, 1.0f);

	for (int j = 0; j < 9; j++) {

		glCallList(55);
		glTranslatef(4, 0, 0);


	}
	glPopMatrix();

	//TROPHY WALL//
	glTranslatef(0, 0, 10);
	glPushMatrix();
	glColor3f(0.0000, 0.3020, 0.5961);
	glTranslatef(4, 2, 2);
	glRotatef(90, 1.0f, 0.0f, 0.0f);
	glScalef(3.0f, 0.01f, 1.0f);
	for (int j = 0; j < 9; j++) {

		glCallList(55);
		glTranslatef(4, 0, 0);


	}

	glEnd();
	glPopMatrix();

	// Draw the floor
	glPushMatrix();
	glColor3f(0.6588, 0.0745, 0.2431); // Set the color of the floor
	glTranslatef(53, -2, -5); // Adjust the position to fit between the lockers
	glScalef(30.2, 0.01, 3.5); // Scale to fit the space
	glutSolidCube(4);
	glPopMatrix();

	//Draw carpet//
	glPushMatrix();
	glColor3f(1.0000, 0.9294, 0.0078); // Set the color of the floor
	glTranslatef(53, -1.85, -5); // Adjust the position to fit between the lockers
	glScalef(30.2, 0.01, 2); // Scale to fit the space
	glutSolidCube(4);
	glPopMatrix();

	// Draw the ceiling
	glPushMatrix();
	glColor3f(0.6588, 0.0745, 0.2431); // Set the color of the floor
	glTranslatef(53, 6, -5); // Adjust the position to fit between the lockers
	glScalef(30.2, 0.01, 3.5); // Scale to fit the space
	glutSolidCube(4);
	glPopMatrix();




}

void drawScreens() {
	glNewList(8, GL_COMPILE);
	glPushMatrix();
	glColor3f(0, 0, 0);
	glTranslatef(0, 1, -0.5);
	glRotatef(-90, 1, 0, 0);
	glRotatef(30, 1, 0, 0);
	glScalef(0.5, 0.05, 0.25); // Adjusted depth to be as flat as possible
	glBegin(GL_QUADS);
	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(2, 0.5, 0);
	glVertex3d(2, 0, 0);

	glVertex3d(2, 0, 0);
	glVertex3d(2, 0.5, 0);
	glVertex3d(2, 0.5, 2.5);
	glVertex3d(2, 0, 2.5);

	glVertex3d(2, 0.5, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(2, 0.5, 2.5);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0, 2.5);
	glVertex3d(2, 0, 2.5);
	glVertex3d(2, 0, 0);

	glVertex3d(0, 0, 0);
	glVertex3d(0, 0.5, 0);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(0, 0, 2.5);

	glVertex3d(0, 0, 2.5);
	glVertex3d(0, 0.5, 2.5);
	glVertex3d(2, 0.5, 2.5);
	glVertex3d(2, 0, 2.5);
	glEnd();
	glPopMatrix();

	//handle
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(0.5, 1.8, -0.5);
	glRotatef(90, 1, 0, 0);
	glScalef(2, 2, 2);
	gluCylinder(obj, 0.005, 0.005, 0.2, 32, 32);
	glPopMatrix();
	glPushMatrix();
	glColor3f(0.4, 0.4, 0.4);
	glTranslatef(0.5, 1.4, -0.5);
	glRotatef(45, 1, 0, 0);
	glScalef(2, 2, 2);
	gluCylinder(obj, 0.005, 0.005, 0.1, 32, 32);
	glPopMatrix();
	glEndList();


	glPushMatrix();
	glTranslatef(1, 0, -0.1);
	for (int i = 0; i < 2; i++)
	{
		glTranslatef(2.5, 0, 0);
		glCallList(8);
	}
	glPopMatrix();

	glPushMatrix();
	glTranslatef(7.1, 0, 1.6);
	glRotatef(-90, 0, 1, 0);
	glCallList(8);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(9, 0, 4.1);
	glRotatef(180, 0, 1, 0);
	for (int i = 0; i < 2; i++)
	{
		glTranslatef(2.5, 0, 0);
		glCallList(8);
	}
	glPopMatrix();

	glPushMatrix();
	glTranslatef(2.9, 0, 2.4);
	glRotatef(90, 0, 1, 0);
	glCallList(8);
	glPopMatrix();

}
void drawScreenText() {
	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-563, 498, -20);
	glRotatef(30, 0, 0, -1);
	glBindTexture(GL_TEXTURE_2D, screen1);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(90, -50, 90);
	glTexCoord2d(1, 0);    glVertex3d(90, -50, -90);
	glTexCoord2d(1, 1);  glVertex3d(90, 50, -90);
	glTexCoord2d(0, 1); glVertex3d(90, 50, 90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(408, 410, 20);
	glRotatef(30, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, screen2);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(90, -50, -90);
	glTexCoord2d(1, 0);    glVertex3d(90, -50, 90);
	glTexCoord2d(1, 1);  glVertex3d(90, 50, 90);
	glTexCoord2d(0, 1); glVertex3d(90, 50, -90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(200, 500, 560);
	glRotatef(90, 0, 1, 0);
	glRotatef(30, 0, 0, -1);
	glBindTexture(GL_TEXTURE_2D, screen3);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(90, -50, 90);
	glTexCoord2d(1, 0);    glVertex3d(90, -50, -90);
	glTexCoord2d(1, 1);  glVertex3d(90, 50, -90);
	glTexCoord2d(0, 1); glVertex3d(90, 50, 90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-300, 500, 560);
	glRotatef(90, 0, 1, 0);
	glRotatef(30, 0, 0, -1);
	glBindTexture(GL_TEXTURE_2D, screen4);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(90, -50, 90);
	glTexCoord2d(1, 0);    glVertex3d(90, -50, -90);
	glTexCoord2d(1, 1);  glVertex3d(90, 50, -90);
	glTexCoord2d(0, 1); glVertex3d(90, 50, 90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(-200, 495, -565);
	glRotatef(90, 0, 1, 0);
	glRotatef(30, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, screen3);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(-90, -50, -90);
	glTexCoord2d(1, 0);    glVertex3d(-90, -50, 90);
	glTexCoord2d(1, 1);  glVertex3d(-90, 50, 90);
	glTexCoord2d(0, 1); glVertex3d(-90, 50, -90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

	glPushMatrix();
	glColor3f(1, 1, 1);
	glTranslatef(300, 495, -565);
	glRotatef(90, 0, 1, 0);
	glRotatef(30, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, screen4);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex3d(-90, -50, -90);
	glTexCoord2d(1, 0);    glVertex3d(-90, -50, 90);
	glTexCoord2d(1, 1);  glVertex3d(-90, 50, 90);
	glTexCoord2d(0, 1); glVertex3d(-90, 50, -90);
	glEnd();
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 255);
	glPopMatrix();

}

void drawsecport() {
	// Draw base
	glPushMatrix();
	glColor3f(0.3, 0.3, 0.3);
	glScalef(0.7, 0.05, 0.3);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw left post
	glPushMatrix();
	glTranslatef(-0.25, 0.75, 0);
	glColor3f(0.3, 0.3, 0.3);
	glScalef(0.03, 1.5, 0.3);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw right post
	glPushMatrix();
	glTranslatef(0.25, 0.75, 0);
	glColor3f(0.3, 0.3, 0.3);
	glScalef(0.03, 1.5, 0.3);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw top bar
	glPushMatrix();
	glTranslatef(0, 1.4, 0);
	glColor3f(0.3, 0.3, 0.3);
	glScalef(0.5, 0.03, 0.3);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw screen on top bar
	glPushMatrix();
	glTranslatef(0, 1.45, 0);
	glColor3f(0.0, 1.0, 0.0);
	glScalef(0.2, 0.05, 0.2);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw conveyor belt
	glPushMatrix();
	glTranslatef(0, -0.025, 0);
	glColor3f(0.3, 0.3, 0.3);
	glScalef(0.7, 0.01, 0.3);
	glutSolidCube(1.0);
	glPopMatrix();

	// Draw wiring at the base
	glPushMatrix();
	glTranslatef(0, -0.05, 0);
	glColor3f(0.0, 0.0, 0.0);
	glScalef(0.7, 0.01, 0.05);
	glutSolidCube(1.0);
	glPopMatrix();

}
void drawreception() {
	glPushMatrix();
	glCallList(301);
	glPopMatrix();
}
void drawoffice() {
	glPushMatrix();
	glScalef(1.4, 1.4, 1.4);
	glCallList(100);
	glPopMatrix();



}

// Room dimensions
const float width = 120.0f;
const float height = 18.0f;
const float depth = 60.0f;

// Door dimensions
const float doorWidth = 10.0f;
const float doorHeight = 18.0f;
const float doorX = 0.0f; // Centered
const float doorY = 50;
void drawpressbox() {



	

	// Draw black borders
	glColor4f(0.0f, 0.0f, 0.0f, 1.0f); // Black color

	glBegin(GL_LINES);
	// Floor
	glVertex3f(-width / 2, 0, -depth / 2);		 glVertex3f(width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, -depth / 2);		 glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(width / 2, 0, depth / 2);		 glVertex3f(-width / 2, 0, depth / 2);
	glVertex3f(-width / 2, 0, depth / 2);        glVertex3f(-width / 2, 0, -depth / 2);

	// Ceiling
	glVertex3f(-width / 2, height, -depth / 2);  glVertex3f(width / 2, height, -depth / 2);
	glVertex3f(width / 2, height, -depth / 2);   glVertex3f(width / 2, height, depth / 2);
	glVertex3f(width / 2, height, depth / 2);    glVertex3f(-width / 2, height, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);   glVertex3f(-width / 2, height, -depth / 2);

	// Front Wall
	glVertex3f(-width / 2, 0, -depth / 2);       glVertex3f(width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, -depth / 2);        glVertex3f(width / 2, height, -depth / 2);
	glVertex3f(width / 2, height, -depth / 2);   glVertex3f(-width / 2, height, -depth / 2);
	glVertex3f(-width / 2, height, -depth / 2);  glVertex3f(-width / 2, 0, -depth / 2);

	// Back Wall
	glVertex3f(-width / 2, 0, depth / 2);        glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(width / 2, 0, depth / 2);         glVertex3f(width / 2, height, depth / 2);
	glVertex3f(width / 2, height, depth / 2);    glVertex3f(-width / 2, height, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);   glVertex3f(-width / 2, 0, depth / 2);

	// Left Wall
	glVertex3f(-width / 2, 0, -depth / 2);       glVertex3f(-width / 2, 0, depth / 2);
	glVertex3f(-width / 2, 0, depth / 2);        glVertex3f(-width / 2, height, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);   glVertex3f(-width / 2, height, -depth / 2);
	glVertex3f(-width / 2, height, -depth / 2);  glVertex3f(-width / 2, 0, -depth / 2);

	// Right Wall
	glVertex3f(width / 2, 0, -depth / 2);        glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(width / 2, 0, depth / 2);         glVertex3f(width / 2, height, depth / 2);
	glVertex3f(width / 2, height, depth / 2);    glVertex3f(width / 2, height, -depth / 2);
	glVertex3f(width / 2, height, -depth / 2);   glVertex3f(width / 2, 0, -depth / 2);

	glEnd();

	//head of section office
	glPushMatrix();
	glTranslatef(36, 7, 0);
	drawoffice();
	glPopMatrix();

	//assistant office1
	glPushMatrix();
	glTranslatef(67, 5, -107);
	glScalef(1.4, 1.4, 1.4);
	glRotatef(90, 0, 1, 0);
	// Disk
	glPushMatrix();
	glColor3ub(77, 77, 77);
	glTranslated(-57.5, 0, -46.25);
	glScaled(4, 0.5, 12.5);
	glutSolidCube(1);
	glPopMatrix();


	// Chair(Disk)
	glPushMatrix();
	glTranslated(-60, -1.75, -46.25);
	glRotated(180, 0, 1, 0);
	glCallList(500);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-57, 2.5, -46);
	glCallList(900);
	glPopMatrix();

	glPopMatrix();


	//assistant office2
	glPushMatrix();
	glTranslatef(44, 5, -107);
	glScalef(1.4, 1.4, 1.4);
	glRotatef(90, 0, 1, 0);
	// Disk
	glPushMatrix();
	glColor3ub(77, 77, 77);
	glTranslated(-57.5, 0, -46.25);
	glScaled(4, 0.5, 12.5);
	glutSolidCube(1);
	glPopMatrix();


	// Chair(Disk)
	glPushMatrix();
	glTranslated(-60, -1.75, -46.25);
	glRotated(180, 0, 1, 0);
	glCallList(500);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-57, 2.5, -46);
	glCallList(900);
	glPopMatrix();

	glPopMatrix();


	//assistant office3
	glPushMatrix();
	glTranslatef(21, 5, -107);
	glScalef(1.4, 1.4, 1.4);
	glRotatef(90, 0, 1, 0);
	// Disk
	glPushMatrix();
	glColor3ub(77, 77, 77);
	glTranslated(-57.5, 0, -46.25);
	glScaled(4, 0.5, 12.5);
	glutSolidCube(1);
	glPopMatrix();


	// Chair(Disk)
	glPushMatrix();
	glTranslated(-60, -1.75, -46.25);
	glRotated(180, 0, 1, 0);
	glCallList(500);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-57, 2.5, -46);
	glCallList(900);
	glPopMatrix();

	glPopMatrix();




	glPushMatrix();
	glTranslatef(-58,0,15);
	glScalef(1.5,1.5,1.5);
	glCallList(50);
	glPopMatrix();

	//door
	glPushMatrix();
	glTranslated(0, 7.5, 30);
	glRotated(180 - doorangle, 0, 1, 0);
	glTranslatef(doorangle / 20, 0, doorangle / 18);
	glCallList(237);
	glPopMatrix();


	glBegin(GL_QUADS);
	glColor3f(0.5, 0.1, 0.5);
	// Floor
	glVertex3f(-width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(-width / 2, 0, depth / 2);

	glColor4f(0.5f, 0.5f, 0.8f, 0.3f); // Light blue with transparency
	// Ceiling
	glVertex3f(-width / 2, height, -depth / 2);
	glVertex3f(width / 2, height, -depth / 2);
	glVertex3f(width / 2, height, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);

	// Front Wall
	glVertex3f(-width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, -depth / 2);
	glVertex3f(width / 2, height, -depth / 2);
	glVertex3f(-width / 2, height, -depth / 2);

	// Back Wall (left part)
	glVertex3f(-width / 2, 0, depth / 2);
	glVertex3f(doorX - doorWidth / 2, 0, depth / 2);
	glVertex3f(doorX - doorWidth / 2, height, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);

	// Back Wall (right part)
	glVertex3f(doorX + doorWidth / 2, 0, depth / 2);
	glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(width / 2, height, depth / 2);
	glVertex3f(doorX + doorWidth / 2, height, depth / 2);

	// Back Wall (above door)
	glVertex3f(doorX - doorWidth / 2, doorHeight, depth / 2);
	glVertex3f(doorX + doorWidth / 2, doorHeight, depth / 2);
	glVertex3f(doorX + doorWidth / 2, height, depth / 2);
	glVertex3f(doorX - doorWidth / 2, height, depth / 2);

	// Left Wall
	glVertex3f(-width / 2, 0, -depth / 2);
	glVertex3f(-width / 2, 0, depth / 2);
	glVertex3f(-width / 2, height, depth / 2);
	glVertex3f(-width / 2, height, -depth / 2);

	// Right Wall
	glVertex3f(width / 2, 0, -depth / 2);
	glVertex3f(width / 2, 0, depth / 2);
	glVertex3f(width / 2, height, depth / 2);
	glVertex3f(width / 2, height, -depth / 2);

	glEnd();
}
void drawamb_place() {
	glPushMatrix();
	glColor3f(1,0,1);
	glTranslatef(-475,0,-360);
	glRotatef(70, 0, 1, 0);
	gluCylinder(obj, 70, 70, 104, 100, 32);
	glPopMatrix();
	
	glPushMatrix();
	glColor3f(1, 0, 1);
	glTranslatef(395, 0, 330);
	glRotatef(70, 0, 1, 0);
	gluCylinder(obj, 70, 70, 104, 100, 32);
	glPopMatrix();


}


// Room dimensions
const float hall_width = 700.0f;
const float hall_height = 100.0f;
const float hall_depth = 800.0f;


void draw_halls() {


	//players
	glPushMatrix();
	glTranslated(0, 0, 950);
	glBegin(GL_QUADS);
	glColor3f(0.3, 0.1, 0.5);
	// Floor
	glVertex3f(-hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, hall_depth / 2);
	glVertex3f(-hall_width / 2, 0, hall_depth / 2);

	glColor3f(0.5f, 0.5f, 0.8f); // Light blue with transparency
	// Ceiling
	glVertex3f(-hall_width / 2, hall_height, -hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, -hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, hall_depth / 2);



	// Left Wall
	glVertex3f(-hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(-hall_width / 2, 0, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, -hall_depth / 2);

	// Right Wall
	glVertex3f(hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, -hall_depth / 2);

	glEnd();

	glPopMatrix();
	//draw walkway1
	glPushMatrix();
	glTranslatef(-18, 13, 660);
	glRotatef(90, 0, 1, 0);
	glScalef(2, 6, 4.9);
	draw_walkway();
	glPopMatrix();



	//public
	glPushMatrix();
	glTranslated(0, 0, -950);
	glBegin(GL_QUADS);
	glColor3f(0.3, 0.1, 0.5);
	// Floor
	glVertex3f(-hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, hall_depth / 2);
	glVertex3f(-hall_width / 2, 0, hall_depth / 2);

	glColor3f(0.5f, 0.5f, 0.8f); // Light blue with transparency
	// Ceiling
	glVertex3f(-hall_width / 2, hall_height, -hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, -hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, hall_depth / 2);



	// Left Wall
	glVertex3f(-hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(-hall_width / 2, 0, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(-hall_width / 2, hall_height, -hall_depth / 2);

	// Right Wall
	glVertex3f(hall_width / 2, 0, -hall_depth / 2);
	glVertex3f(hall_width / 2, 0, hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, hall_depth / 2);
	glVertex3f(hall_width / 2, hall_height, -hall_depth / 2);

	glEnd();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(120, 30, -1220);

	glScalef(3, 3, 3);
	drawreception();
	glPopMatrix();

	//draw walkway2
	glPushMatrix();
	glTranslatef(-30, 13, -455);
	glRotatef(90, 0, 1, 0);
	glScalef(2, 6, 4.9);
	draw_walkway();
	glPopMatrix();
}


void draw() {
	//glPushMatrix();

	////Laboratory


	////Table(Lab).
	//glTranslated(-67.5, 0, -52.5);
	//glColor3ub(175, 214, 157);
	//glScaled(4, 0.5, 10);
	//glutSolidCube(1);
	//glPopMatrix();
	//glPushMatrix();

	////Table Leg (Lab).
	//glTranslated(-67.5, -2, -52.5);
	//glColor3ub(137, 168, 123);
	//glScaled(0.5, 4, 9);
	//glutSolidCube(1);
	//glPopMatrix();
	//glPushMatrix();

	////Upper Right rounded Chair(Lab).
	//glTranslated(-64.5, -1, -55.5);
	//glCallList(705);
	//glPopMatrix();
	//glPushMatrix();

	////Lower Right rounded Chair(Lab).
	//glTranslated(-64.5, -1, -49.5);
	//glCallList(705);
	//glPopMatrix();
	//glPushMatrix();

	////Lower Left rounded Chair(Lab).
	//glTranslated(-70.5, -1, -49.5);
	//glCallList(705);
	//glPopMatrix();
	//glPushMatrix();

	////Upper Left rounded Chair(Lab).
	//glTranslated(-70.5, -1, -55.5);
	//glCallList(705);
	//glPopMatrix();
	//glPushMatrix();

	//Right Disk(Lab).
	glColor3ub(77, 77, 77);
	glTranslated(-57.5, 0, -46.25);
	glScaled(4, 0.5, 12.5);
	glutSolidCube(1);
	glPopMatrix();
	glPushMatrix();

	//Right Chair(Disk(Lab)).
	glTranslated(-60, -1.75, -46.25);
	glRotated(180, 0, 1, 0);
	glCallList(500);
	glPopMatrix();
	glPushMatrix();

	////Left Screen(disk(Lab)).
	//glTranslated(-57.5, 2.25, -46.25);
	//glCallList(900);
	//glPopMatrix();
	//glPushMatrix();

	////Left Disk(Lab).
	//glColor3ub(77, 77, 77);
	//glTranslated(-78, 0, -46.25);
	//glScaled(4, 0.5, 12.5);
	//glutSolidCube(1);
	//glPopMatrix();
	//glPushMatrix();

	////Left Chair(Disk(Lab)).
	//glTranslated(-74.5, -1.75, -46.25);
	//glCallList(500);
	//glPopMatrix();
	//glPushMatrix();

	////Left Screen(disk(Lab)).
	//glTranslated(-78, 2.25, -46.25);
	//glCallList(900);
	//glPopMatrix();

	glNewList(237, GL_COMPILE);
	glPushMatrix();
	glColor3ub(128, 102, 74);
	glScaled(10, 16, 0.125);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	glColor3ub(89, 71, 52);
	glTranslated(3, -1, -.375);
	gluSphere(obj, 0.375, 25, 25);
	glPopMatrix();
	glEndList();


	glNewList(239, GL_COMPILE);
	glPushMatrix();
	glScaled(1.1, 1, 1);
	glCallList(237);
	glPopMatrix();
	glEndList();




}
void drawloackers() {
	//lockers//
	glPushMatrix();
	glTranslatef(0, 0, -1);
	for (int i = 1; i <= 11; i++)
	{
		glTranslatef(3, 0, 0);
		glCallList(580);
	}
	glTranslatef(5, 0, 10);
	glRotatef(180, 0, 1, 0);
	for (int i = 0; i < 11; i++)
	{
		glTranslatef(3, 0, 0);
		glCallList(580);
	}
	glPopMatrix();

	//the block
	glPushMatrix();
	glColor3f(0.949, 0.8588, 0.7765);
	glTranslatef(4, 2, -3);
	glRotatef(90, 1.0f, 0.0f, 0.0f);
	glScalef(1.0f, 0.01f, 1.0f);

	for (int j = 0; j < 9; j++) {

		glCallList(551);
		glTranslatef(4, 0, 0);


	}
	glPopMatrix();
	glTranslatef(0, 0, 10);
	glPushMatrix();
	glColor3f(0.949, 0.8588, 0.7765);
	glTranslatef(4, 2, 2);
	glRotatef(90, 1.0f, 0.0f, 0.0f);
	glScalef(1.0f, 0.01f, 1.0f);
	for (int j = 0; j < 9; j++) {

		glCallList(351);
		glTranslatef(4, 0, 0);


	}

	glEnd();
	glPopMatrix();

	// Draw the floor
	glPushMatrix();
	glColor3f(0.5f, 0.5f, 0.5f); // Set the color of the floor
	glTranslatef(20, -1.5, -6); // Adjust the position to fit between the lockers
	glScalef(10, 0.01, 3.5); // Scale to fit the space
	glutSolidCube(4);
	glPopMatrix();

	glPushMatrix();
	for (int i = 0; i < 5; i++)
	{
		glCallList(9);
		glTranslatef(0, 0, -2);
	}
	glPopMatrix();

	glPushMatrix();
	glTranslatef(40, 0, 0);
	for (int i = 0; i < 5; i++)
	{
		glCallList(9);
		glTranslatef(0, 0, -2);
	}
	glPopMatrix();

	//Table.
	glPushMatrix();
	glTranslated(-18, 0, -2.5);
	glScalef(2, 0.5, 0.5);
	glPushMatrix();
	glTranslated(20, 0, -5.5);
	glRotatef(90, 0, 1, 0);
	glColor3ub(175, 214, 157);
	glScaled(4, 0.5, 10);
	glutSolidCube(1);
	glPopMatrix();
	//Table Leg.
	glPushMatrix();
	glTranslated(20, -1.5, -5.5);
	glRotatef(90, 0, 1, 0);
	glColor3ub(137, 168, 123);
	glScaled(0.5, 3, 9);
	glutSolidCube(1);
	glPopMatrix();
	glPopMatrix();

	//chairs//
	glPushMatrix();
	glTranslated(30, -1, -4);
	glRotatef(270, 0, 1, 0);
	glScalef(0.5, 0.5, 0.5);
	for (int i = 0; i < 4; i++)
	{
		glTranslated(0, 0, 8);
		glCallList(500);
	}
	glPopMatrix();

	glPushMatrix();
	glTranslated(10, -1, -6.5);
	glRotatef(90, 0, 1, 0);
	glScalef(0.5, 0.5, 0.5);
	for (int i = 0; i < 4; i++)
	{
		glTranslated(0, 0, 8);
		glCallList(500);
	}
	glPopMatrix();


}

void DrawGLScene(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	//update();
	Camera(); //for setting up the camera movment and target position


	glPushMatrix();
	drawSkybox();
	glPopMatrix();

	glPushMatrix();
	drawField();
	glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, 255);//to clear the texture buffer

	glPushMatrix();
	glTranslatef(0, -1, 0);
	glScalef(1, 0, 1);
	glColor3ub(144, 238, 144);
	glutSolidCube(2000);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, -2, 0);
	glScalef(1, 0, 1);
	glColor3ub(120, 120, 120);
	glutSolidCube(4900);
	glPopMatrix();

	//draw flages
	glPushMatrix();
	drawFlags();
	glPopMatrix();


	//draw goal1
	glPushMatrix();
	glTranslatef(-285, 25, 35);
	glRotatef(90, 0, 1, 0);
	drawGoal();
	glPopMatrix();
	//draw goal2
	glPushMatrix();
	glTranslatef(285, 25, -35);
	glRotatef(-90, 0, 1, 0);
	drawGoal();
	glPopMatrix();

	//draw subseats
	glPushMatrix();
	glTranslatef(-120, 12, 225);
	glRotatef(270, 0, 1, 0);
	drawSubseat();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(120, 12, 225);
	glRotatef(270, 0, 1, 0);
	drawSubseat();
	glPopMatrix();

	//draw bunch
	glPushMatrix();
	glTranslatef(0, 8, 225);
	glRotatef(180, 0, 1, 0);
	drawBunch();
	glPopMatrix();

	glColor3f(1, 1, 1);



	//draw commertial boards
	glPushMatrix();
	//boards
	glPushMatrix();
	glTranslatef(0, 15, 0);
	glRotatef(90, 1, 0, 0);
	glRotatef(45, 0, 0, 1);
	glScalef(1, 1, 0.8);
	drawBoarder();
	glPopMatrix();
	//commertials
	drawAdidas();
	drawQatar();
	drawPs5();
	drawMaster();
	drawAramco();
	drawSupra();
	drawEmirates();
	drawcontinental();
	glPopMatrix();


	//draw barca
	glPushMatrix();
	drawBarca();
	glPopMatrix();



	glPushMatrix();//draw stands
	glTranslatef(140, 0, -218);
	glScalef(1.9, 1.9, 1.9);
	draw_stands();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-140, 0, 218);
	glScalef(1.9, 1.9, 1.9);
	glRotatef(180, 0, 1, 0);
	draw_stands();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 550, 0);
	glScalef(1.5, 1.5, 1.5);
	draw_roof();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, 550, 0);
	glRotatef(180, 0, 1, 0);
	glScalef(1.5, 1.5, 1.5);
	draw_roof();
	glPopMatrix();

	//draw pressbox 1
	glPushMatrix();
	glTranslatef(-9,310,-774);
	glRotatef(180, 0, 1, 0);
	glScalef(1.8,1.9,1.9);
	drawpressbox();
	glPopMatrix();
	//draw pressbox 1
	glPushMatrix();
	glTranslatef(+9, 310, +774);
	glScalef(1.8, 1.9, 1.9);
	drawpressbox();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-418, 15, -330);
	glScaled(1.9, 1.9, 1.9);
	glRotated(65, 0, 1, 0);
	glCallList(101);
	glPopMatrix();

	glPushMatrix();
	glTranslated(418, 15, 330);
	glScaled(1.9, 1.9, 1.9);
	glRotated(245, 0, 1, 0);
	glCallList(101);
	glPopMatrix();


	glPushMatrix();
	;
	draw_halls();
	
	glPopMatrix();

	

	drawamb_place();
	

	glPushMatrix();
	glTranslatef(0, 560, 20);
	glScalef(1.5, 1.5, 1.5);
	double ffw[4] = { 0, 0, 1,0 };
	glEnable(GL_CLIP_PLANE0);
	glClipPlane(GL_CLIP_PLANE0, ffw);
	glTranslatef(0, -240, 0);
	glRotatef(90, 0, 1, 0);
	glPushMatrix();
	glScalef(1.5, 1, 1);
	glRotatef(90, 1, 0, 0);
	glColor3f(0, 0.4, 0.7);
	GLUquadricObj* sh = gluNewQuadric();
	gluCylinder(sh, 640, 640, 280, 60, 60);
	glDisable(GL_CLIP_PLANE0);
	glPopMatrix();
	glPopMatrix();

	//banners
	glPushMatrix();
	drawBanners();
	glPopMatrix();

	//cameras
	glPushMatrix();
	drawCameras();
	glPopMatrix();

	//main door
	glPushMatrix();
	glTranslatef(-120, 15, -1393);
	glRotatef(90, 0, 1, 0);
	// auto door1
	glPushMatrix();
	glTranslatef(27, 36.55, auto_door1);
	glScalef(0.15, 300, 350);
	glColor3ub(89, 89, 89);
	glutSolidCube(1);
	glPopMatrix();
	// auto door2
	glPushMatrix();
	glTranslatef(27, 36.55, auto_door2);
	glScalef(0.15, 300, 350);
	glColor3ub(89, 89, 89);
	glutSolidCube(1);
	glPopMatrix();

	glEnable(GL_BLEND);								   // for blinging دمج الالوان
	glBlendFunc(GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR); // لدمج الالوان
	// auto door window1
	glPushMatrix();
	glTranslatef(27, 39.5, auto_door1-95);
	glScalef(0.2, 50, 50);
	glColor4ub(66, 66, 155, 1);
	glutSolidCube(1);
	glPopMatrix();
	// auto doorwindow2
	glPushMatrix();
	glTranslatef(27, 39.5, auto_door2+tz);
	glScalef(0.2, 50, 50);
	glColor4ub(66, 66, 155, 1);
	glutSolidCube(1);
	glPopMatrix();
	glDisable(GL_BLEND);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0,10,1095);
	glScalef(6,6,6);
	drawloackers();
	glPopMatrix();

	

	//draw screens

	glTranslatef(0,-50,0 );
	glPushMatrix();
	glPushMatrix();
	glTranslatef(-1000, 200, -400);
	glScalef(200, 200, 200);
	drawScreens();
	glPopMatrix();
	glPushMatrix();
	drawScreenText();
	glPopMatrix();
	glPopMatrix();



	glPushMatrix();
	glTranslatef(-500, 50, -1675);
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 15; j++) {
			glCallList(655);
			glTranslatef(0, 0, -90);
		}
		glTranslatef(90, 0, 1350);
	}
	glScalef(6, 6, 6);

	glPopMatrix();
	glPushMatrix();
	glTranslatef(375, 50, -1675);
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 15; j++) {
			glCallList(655);
			glTranslatef(0, 0, -90);
		}
		glTranslatef(90, 0, 1350);
	}
	glScalef(6, 6, 6);

	glPopMatrix();



	Spine();

	glColor3f(1, 1, 1);
	glutSwapBuffers();

}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE); // Use double display buffer.

	glutInitWindowSize(640, 640);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("EMPTY WINDOW");

	glutFullScreen();

	//Make the default cursor disappear
	glutSetCursor(GLUT_CURSOR_NONE);

	InitGL();
	glutReshapeFunc(ReSizeGLScene);
	glutDisplayFunc(DrawGLScene);
	glutTimerFunc(0, timer, 0);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(special);
	glutPassiveMotionFunc(passiveMotion);
	//glutMotionFunc(ReadMouseMotion);

	glutMainLoop();

	return 0;
}


